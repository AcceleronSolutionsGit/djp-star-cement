import express from 'express';
import { uploadFile, uploadMiddleware, processUpload, getUploadBatches, deleteUploadBatch } from '../controllers/upload.controller.js';
import { getRules, updateRule } from '../controllers/rules.controller.js';
import { 
  getDashboardStats, 
  getFilterOptions, 
  getTerritoryMapping, 
  updateRulesBatch,
  getMasterSummary,
  getMasterFilterOptions,
  getMasterDealers,
  getMasterEmployees,
  getSalesHistory,
  getVisitExecutionLogs,
  purgeOldData
} from '../controllers/admin.controller.js';
import { 
  getDealerVisitTargets, 
  getDjpPlan, 
  calculatePjp, 
  getPjpDebug, 
  exportPjpTradeExcel,
  exportMasterExcel,
  exportVisitsExcel,
  getReconciliationDiagnostics,
  getInputReadiness
} from '../controllers/djp.controller.js';
import { createGenerationRun, executeGenerationRun, listGenerationRuns, getGenerationRun, generateAllLegacy } from '../controllers/generation.controller.js';
import { generateAutoPlan, runDealerMapping, submitPlan, approvePlan, getPlans, getPlanDetails, getAllEmployees, addPlanVisit, removePlanVisit, movePlanVisit, getDealersForSO, deletePlan, bulkDeletePlans } from '../controllers/plan.controller.js';
import { login } from '../controllers/auth.controller.js';

const router = express.Router();

// Auth APIs
router.post('/auth/login', login);

// Master Data APIs
router.get('/master/summary', getMasterSummary);
router.get('/master/filters', getMasterFilterOptions);
router.get('/master/dealers', getMasterDealers);
router.get('/master/employees', getMasterEmployees);
router.get('/master/sales-history', getSalesHistory);
router.get('/master/visit-logs', getVisitExecutionLogs);

// Plan Workflows & Dealer Mapping APIs
router.post('/plans/generate', generateAutoPlan);
router.post('/plans/mapping/run', runDealerMapping);
router.post('/plans/submit', submitPlan);
router.post('/plans/approve', approvePlan);
router.post('/plans/bulk-delete', bulkDeletePlans);
router.get('/plans', getPlans);
router.delete('/plans/:planId', deletePlan);
router.get('/plans/:planId/details', getPlanDetails);
router.get('/plans/dealers', getDealersForSO);
router.post('/plans/details', addPlanVisit);
router.delete('/plans/details/:detailId', removePlanVisit);
router.put('/plans/details/move', movePlanVisit);
router.get('/employees', getAllEmployees);

// Upload APIs
router.post('/uploads/file', uploadMiddleware.single('file'), uploadFile);
router.post('/uploads/process', processUpload);
router.get('/admin/batches', getUploadBatches);
router.delete('/admin/batches/:batchCode', deleteUploadBatch);

// Admin Dashboard & Options APIs
router.get('/admin/stats', getDashboardStats);
router.get('/admin/filters', getFilterOptions);
router.get('/admin/mapping', getTerritoryMapping);
router.get('/admin/readiness', getInputReadiness);
router.delete('/admin/purge', purgeOldData);

// Business Rules APIs
router.get('/admin/rules', getRules);
router.put('/admin/rules', updateRule);
router.put('/admin/rules/batch', updateRulesBatch);

// DJP Engine APIs — legacy single-shot endpoint (uses latest batches auto)
router.post('/djp/generate-all', generateAllLegacy);
router.get('/djp/dealer-targets', getDealerVisitTargets);
router.get('/djp/export-pjp-trade', exportPjpTradeExcel);
router.get('/djp/export-master', exportMasterExcel);
router.get('/djp/export-visits', exportVisitsExcel);
router.get('/djp/reconciliation', getReconciliationDiagnostics);
router.get('/djp/plan', getDjpPlan);

// Generation Run APIs (batch-isolated)
router.post('/generation/create', createGenerationRun);
router.post('/generation/run/:code', executeGenerationRun);
router.get('/generation', listGenerationRuns);
router.get('/generation/:code', getGenerationRun);

// PJP Canonical Engine APIs
router.post('/pjp/calculate', calculatePjp);
router.get('/pjp/export-master', exportMasterExcel);
router.get('/pjp/export-visits', exportVisitsExcel);
router.get('/pjp/reconciliation', getReconciliationDiagnostics);
router.get('/pjp/debug/:dealerCode', getPjpDebug);

export default router;
