/**
 * Generation Controller — Batch-Isolated PJP/DJP Generation
 *
 * Each generation run is a first-class entity that explicitly declares:
 * - which dealer mapping batch to use
 * - which sales history batches to use
 * - which prospect batch to use (optional)
 * - which rules version to use
 *
 * Two generation runs CANNOT contaminate each other.
 * Historical runs remain reproducible.
 */

import { calculatePJP } from '../engines/pjp/pjp.engine.js';
import { generateFullPjpDjpSolution } from '../engines/djp-generator.engine.js';
import { checkAllExcelInputsAvailable } from '../engines/pjp/data-loader.engine.js';
import { dbRun, dbAll, dbGet } from '../config/database.js';

/**
 * Create a new generation run record (without executing).
 * POST /api/generation/create
 * Body: { reportMonth, cycleCode, dealerMappingBatchCode, salesHistoryBatchCodes[], prospectBatchCode? }
 */
export async function createGenerationRun(req, res) {
  try {
    const planMonth = req.body.planMonth || req.body.periodMonth || req.body.reportMonth;
    const {
      cycleCode,
      dealerMappingBatchCode,
      salesHistoryBatchCodes,
      prospectBatchCode,
      sfaFeedbackBatchCode
    } = req.body;

    if (!planMonth || typeof planMonth !== 'string') {
      return res.status(400).json({ error: 'planMonth is required. Please specify the planning month in YYYY-MM format.' });
    }
    const match = planMonth.match(/^(\d{4})-(\d{2})$/);
    if (!match) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Expected format is YYYY-MM.` });
    }
    const mNum = parseInt(match[2], 10);
    if (mNum < 1 || mNum > 12) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Month must be between 01 and 12.` });
    }
    const reportMonth = planMonth;

    if (!cycleCode) return res.status(400).json({ error: 'cycleCode is required (C1 or C2)' });
    if (!dealerMappingBatchCode) return res.status(400).json({ error: 'dealerMappingBatchCode is required' });

    // Validate the batches exist
    const mappingBatch = await dbGet('SELECT batch_code, status FROM upload_batches WHERE batch_code = ? AND file_type = ?', [dealerMappingBatchCode, 'DEALER_MAPPING']);
    if (!mappingBatch) return res.status(400).json({ error: `Dealer mapping batch '${dealerMappingBatchCode}' not found` });
    if (mappingBatch.status === 'FAILED') return res.status(400).json({ error: `Dealer mapping batch '${dealerMappingBatchCode}' has status FAILED — cannot use it for generation` });

    // Validate sales batches
    const salesBatchCodes = Array.isArray(salesHistoryBatchCodes) ? salesHistoryBatchCodes : [];
    for (const code of salesBatchCodes) {
      const b = await dbGet('SELECT batch_code, status FROM upload_batches WHERE batch_code = ? AND file_type = ?', [code, 'SALES_HISTORY']);
      if (!b) return res.status(400).json({ error: `Sales history batch '${code}' not found` });
      if (b.status === 'FAILED') return res.status(400).json({ error: `Sales history batch '${code}' has status FAILED` });
    }

    // Snapshot current rules
    const rulesRows = await dbAll('SELECT rule_key, rule_value FROM business_rules');
    const rulesSnapshot = JSON.stringify(Object.fromEntries(rulesRows.map(r => [r.rule_key, r.rule_value])));

    const generationCode = `GEN-${reportMonth.replace('-', '')}-${cycleCode}-${Date.now()}`;

    await dbRun(
      `INSERT INTO generation_runs 
      (generation_code, report_month, cycle_code, dealer_mapping_batch_code, sales_history_batch_codes, prospect_batch_code, sfa_feedback_batch_code, rules_snapshot, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        generationCode, reportMonth, cycleCode,
        dealerMappingBatchCode,
        JSON.stringify(salesBatchCodes),
        prospectBatchCode || null,
        sfaFeedbackBatchCode || null,
        rulesSnapshot,
        'PENDING'
      ]
    );

    res.json({
      message: 'Generation run created. Call POST /api/generation/run/:code to execute.',
      generationCode,
      reportMonth,
      cycleCode,
      dealerMappingBatchCode,
      salesHistoryBatchCodes: salesBatchCodes,
      prospectBatchCode: prospectBatchCode || null
    });
  } catch (err) {
    console.error('[createGenerationRun]', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Execute a pending generation run.
 * POST /api/generation/run/:code
 */
export async function executeGenerationRun(req, res) {
  const { code } = req.params;

  try {
    const run = await dbGet('SELECT * FROM generation_runs WHERE generation_code = ?', [code]);
    if (!run) return res.status(404).json({ error: `Generation run '${code}' not found` });
    if (run.status === 'RUNNING') return res.status(409).json({ error: `Generation run '${code}' is already running` });
    if (run.status === 'COMPLETED') {
      return res.status(409).json({ error: `Generation run '${code}' already completed. Create a new run to regenerate.` });
    }

    // Mark as running
    await dbRun('UPDATE generation_runs SET status = ? WHERE generation_code = ?', ['RUNNING', code]);

    const salesBatchCodes = JSON.parse(run.sales_history_batch_codes || '[]');

    // Execute PJP + DJP
    const result = await generateFullPjpDjpSolution(run.report_month, run.cycle_code, {
      generationRunCode: code,
      dealerMappingBatchCode: run.dealer_mapping_batch_code,
      salesHistoryBatchCodes: salesBatchCodes,
      prospectBatchCode: run.prospect_batch_code
    });

    // Update generation run with results
    const validationErrors = result.validationErrors?.length > 0
      ? JSON.stringify(result.validationErrors.slice(0, 50))
      : null;

    await dbRun(
      `UPDATE generation_runs SET 
       status = ?, pjp_dealer_count = ?, pjp_visit_requirement = ?,
       djp_scheduled_count = ?, djp_unallocated_count = ?,
       capacity_violated = ?, validation_errors = ?, completed_at = NOW()
       WHERE generation_code = ?`,
      [
        result.unallocatedCount > 0 ? 'PARTIAL' : 'COMPLETED',
        result.totalDealerTargets || 0,
        result.totalVisitsRequired || 0,
        result.totalDjpSlots || 0,
        result.unallocatedCount || 0,
        result.capacityViolated ? 1 : 0,
        validationErrors,
        code
      ]
    );

    res.json({
      message: result.unallocatedCount > 0
        ? `Generation completed with ${result.unallocatedCount} unallocated visits (capacity constraints).`
        : 'Generation completed successfully.',
      generationCode: code,
      reportMonth: run.report_month,
      cycleCode: run.cycle_code,
      ...result
    });
  } catch (err) {
    console.error('[executeGenerationRun]', err);
    // Mark as failed
    await dbRun('UPDATE generation_runs SET status = ?, validation_errors = ?, completed_at = NOW() WHERE generation_code = ?', [
      'FAILED', err.message, code
    ]);
    res.status(500).json({ error: err.message });
  }
}

/**
 * List all generation runs.
 * GET /api/generation
 */
export async function listGenerationRuns(req, res) {
  try {
    const runs = await dbAll('SELECT * FROM generation_runs ORDER BY started_at DESC LIMIT 50');
    res.json({ runs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get a specific generation run.
 * GET /api/generation/:code
 */
export async function getGenerationRun(req, res) {
  try {
    const run = await dbGet('SELECT * FROM generation_runs WHERE generation_code = ?', [req.params.code]);
    if (!run) return res.status(404).json({ error: 'Generation run not found' });
    res.json({ run });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

/**
 * Legacy single-shot generate endpoint (for backward compatibility with existing frontend).
 * POST /api/djp/generate-all
 * Automatically selects the latest VALIDATED batch of each type.
 */
export async function generateAllLegacy(req, res) {
  try {
    const planMonth = req.body.planMonth || req.body.periodMonth || req.body.reportMonth;
    const cycleCode = req.body.cycleCode || 'C1';

    if (!planMonth || typeof planMonth !== 'string') {
      return res.status(400).json({ error: 'planMonth is required. Please specify the planning month in YYYY-MM format.' });
    }
    const match = planMonth.match(/^(\d{4})-(\d{2})$/);
    if (!match) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Expected format is YYYY-MM (e.g., '2026-09').` });
    }
    const mNum = parseInt(match[2], 10);
    if (mNum < 1 || mNum > 12) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Month must be between 01 and 12.` });
    }
    const periodMonth = planMonth;

    // Enforce that ALL 5 Excel input files are available before generating DJP
    const inputCheck = await checkAllExcelInputsAvailable();
    if (!inputCheck.allAvailable) {
      return res.status(400).json({
        error: `Cannot generate DJP: All 5 Excel input files must be uploaded and validated first. Currently missing: ${inputCheck.missing.join(', ')}.`
      });
    }

    // Auto-select latest VALIDATED batches
    const mappingBatch = await dbGet(
      `SELECT batch_code FROM upload_batches WHERE file_type = 'DEALER_MAPPING' AND status != 'FAILED' ORDER BY uploaded_at DESC LIMIT 1`
    );
    const salesBatches = await dbAll(
      `SELECT batch_code FROM upload_batches WHERE file_type = 'SALES_HISTORY' AND status != 'FAILED' ORDER BY uploaded_at DESC LIMIT 10`
    );

    if (!mappingBatch) {
      return res.status(400).json({ error: 'No valid DEALER_MAPPING batch found. Upload dealer master data first.' });
    }

    const salesBatchCodes = salesBatches.map(b => b.batch_code);
    const generationCode = `GEN-${periodMonth.replace('-', '')}-${cycleCode}-${Date.now()}`;
    const rulesRows = await dbAll('SELECT rule_key, rule_value FROM business_rules');
    const rulesSnapshot = JSON.stringify(Object.fromEntries(rulesRows.map(r => [r.rule_key, r.rule_value])));

    await dbRun(
      `INSERT INTO generation_runs 
      (generation_code, report_month, cycle_code, dealer_mapping_batch_code, sales_history_batch_codes, rules_snapshot, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [generationCode, periodMonth, cycleCode, mappingBatch.batch_code, JSON.stringify(salesBatchCodes), rulesSnapshot, 'RUNNING']
    );

    const result = await generateFullPjpDjpSolution(periodMonth, cycleCode, {
      generationRunCode: generationCode,
      dealerMappingBatchCode: mappingBatch.batch_code,
      salesHistoryBatchCodes: salesBatchCodes
    });

    const status = result.unallocatedCount > 0 ? 'PARTIAL' : 'COMPLETED';
    await dbRun(
      `UPDATE generation_runs SET 
       status = ?, pjp_dealer_count = ?, pjp_visit_requirement = ?,
       djp_scheduled_count = ?, djp_unallocated_count = ?, completed_at = NOW()
       WHERE generation_code = ?`,
      [status, result.totalDealerTargets || 0, result.totalVisitsRequired || 0,
       result.totalDjpSlots || 0, result.unallocatedCount || 0, generationCode]
    );

    res.json({
      message: 'Multi-Role PJP & DJP Solution Generated',
      generationCode,
      periodMonth,
      cycleCode,
      dealerMappingBatchUsed: mappingBatch.batch_code,
      salesBatchesUsed: salesBatchCodes,
      ...result
    });
  } catch (err) {
    console.error('[generateAllLegacy]', err);
    res.status(500).json({ error: err.message });
  }
}
