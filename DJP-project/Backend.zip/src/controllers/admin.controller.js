import { dbAll, dbGet, dbRun } from '../config/database.js';

/**
 * Get aggregate counters for admin dashboard header stats
 */
export async function getDashboardStats(req, res) {
  try {
    const totalDealersObj = await dbGet('SELECT COUNT(*) as count FROM master_dealers WHERE status = "ACTIVE" OR status IS NULL');
    const totalAreasObj = await dbGet('SELECT COUNT(DISTINCT area) as count FROM master_dealer_so_mapping WHERE area IS NOT NULL AND area != ""');

    const visitsObj = await dbGet(`
      SELECT 
        SUM(so_visits) as total_so,
        SUM(asm_visits) as total_asm,
        SUM(rsm_visits) as total_rsm,
        SUM(zh_visits) as total_zh,
        COUNT(DISTINCT dealer_name) as target_dealers
      FROM dealer_visit_targets
    `);

    res.json({
      stats: {
        totalDealers: visitsObj?.target_dealers || totalDealersObj?.count || 0,
        totalAreas: totalAreasObj?.count || 0,
        soVisits: Math.round((visitsObj?.total_so || 0) * 10) / 10,
        asmVisits: Math.round((visitsObj?.total_asm || 0) * 10) / 10,
        rsmVisits: Math.round((visitsObj?.total_rsm || 0) * 10) / 10,
        zhVisits: Math.round((visitsObj?.total_zh || 0) * 10) / 10
      }
    });
  } catch (err) {
    console.error('Error fetching dashboard stats:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get distinct filter dropdown options for Zone, Area, SO, Category
 */
export async function getFilterOptions(req, res) {
  try {
    const zones = await dbAll(`
      SELECT DISTINCT zone FROM (
        SELECT zone FROM dealer_visit_targets WHERE zone IS NOT NULL AND zone != ""
        UNION
        SELECT region as zone FROM master_dealer_so_mapping WHERE region IS NOT NULL AND region != ""
      ) AS zone_subquery ORDER BY zone ASC
    `);

    const areas = await dbAll(`
      SELECT DISTINCT area FROM (
        SELECT area FROM dealer_visit_targets WHERE area IS NOT NULL AND area != ""
        UNION
        SELECT area FROM master_dealer_so_mapping WHERE area IS NOT NULL AND area != ""
      ) AS area_subquery ORDER BY area ASC
    `);

    const sos = await dbAll(`
      SELECT DISTINCT so_name FROM (
        SELECT so_name FROM dealer_visit_targets WHERE so_name IS NOT NULL AND so_name != ""
        UNION
        SELECT so_name FROM master_dealer_so_mapping WHERE so_name IS NOT NULL AND so_name != ""
      ) AS so_subquery ORDER BY so_name ASC
    `);

    const statuses = await dbAll(`
      SELECT DISTINCT dealer_status as name FROM dealer_visit_targets WHERE dealer_status IS NOT NULL ORDER BY dealer_status ASC
    `);

    res.json({
      zones: zones.map(z => z.zone),
      areas: areas.map(a => a.area),
      salesOfficers: sos.map(s => s.so_name),
      dealerStatuses: statuses.map(s => s.name)
    });
  } catch (err) {
    console.error('Error fetching filter options:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Batch update business rules
 */
export async function updateRulesBatch(req, res) {
  try {
    const { rules } = req.body;
    if (!Array.isArray(rules) || rules.length === 0) {
      return res.status(400).json({ error: 'Array of rules is required' });
    }

    for (const rule of rules) {
      const { rule_key, rule_value, rule_name, data_type, description } = rule;
      if (rule_key && rule_value !== undefined) {
        // Check if exists
        const existing = await dbGet('SELECT id FROM business_rules WHERE rule_key = ?', [rule_key]);
        if (existing) {
          await dbRun(
            'UPDATE business_rules SET rule_value = ?, updated_at = CURRENT_TIMESTAMP WHERE rule_key = ?',
            [String(rule_value), rule_key]
          );
        } else {
          await dbRun(
            'INSERT INTO business_rules (rule_key, rule_name, rule_value, data_type, description) VALUES (?, ?, ?, ?, ?)',
            [rule_key, rule_name || rule_key, String(rule_value), data_type || 'STRING', description || '']
          );
        }
      }
    }

    const updatedRules = await dbAll('SELECT * FROM business_rules ORDER BY id ASC');
    res.json({ message: 'Rules batch updated successfully', rules: updatedRules });
  } catch (err) {
    console.error('Error updating rules batch:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get aggregate summary counts for all uploaded master data
 */
export async function getMasterSummary(req, res) {
  try {
    const [dealers, prospects, employees, sales, logs, mappings, targets, batches] = await Promise.all([
      dbGet('SELECT COUNT(*) as cnt FROM master_dealers WHERE dealer_type != "PROSPECTIVE"'),
      dbGet('SELECT COUNT(*) as cnt FROM master_dealers WHERE dealer_type = "PROSPECTIVE" OR counter_strategy = "PROSPECT"'),
      dbGet('SELECT COUNT(*) as cnt FROM master_employees'),
      dbGet('SELECT COUNT(*) as cnt FROM sales_history'),
      dbGet('SELECT COUNT(*) as cnt FROM visit_execution_logs'),
      dbGet('SELECT COUNT(*) as cnt FROM master_dealer_so_mapping'),
      dbGet('SELECT COUNT(*) as cnt FROM dealer_visit_targets'),
      dbGet('SELECT COUNT(*) as cnt FROM upload_batches')
    ]);

    res.json({
      summary: {
        totalDealers: dealers?.cnt || 0,
        totalProspects: prospects?.cnt || 0,
        totalEmployees: employees?.cnt || 0,
        totalSalesRecords: sales?.cnt || 0,
        totalVisitLogs: logs?.cnt || 0,
        totalMappings: mappings?.cnt || 0,
        totalTargets: targets?.cnt || 0,
        totalBatches: batches?.cnt || 0
      }
    });
  } catch (err) {
    console.error('Error fetching master summary:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get distinct filter options across all master tables
 */
export async function getMasterFilterOptions(req, res) {
  try {
    const [
      dealerZones,
      dealerRegions,
      dealerAreas,
      dealerTypes,
      dealerStatuses,
      salesPeriods,
      salesZones,
      logBranches,
      logRoutes,
      logEmployees,
      logStatuses,
      logVisitDates,
      logCustomerTypes,
      mappingAreas,
      mappingRegions,
      mappingSos,
      pjpZones,
      pjpAreas,
      pjpSos,
      pjpCategories,
      pjpStatuses
    ] = await Promise.all([
      dbAll('SELECT DISTINCT zone FROM master_dealers WHERE zone IS NOT NULL AND zone != "" ORDER BY zone ASC'),
      dbAll('SELECT DISTINCT region FROM master_dealers WHERE region IS NOT NULL AND region != "" ORDER BY region ASC'),
      dbAll('SELECT DISTINCT area FROM master_dealers WHERE area IS NOT NULL AND area != "" ORDER BY area ASC'),
      dbAll('SELECT DISTINCT dealer_type FROM master_dealers WHERE dealer_type IS NOT NULL AND dealer_type != "" ORDER BY dealer_type ASC'),
      dbAll('SELECT DISTINCT status FROM master_dealers WHERE status IS NOT NULL AND status != "" ORDER BY status ASC'),
      dbAll('SELECT DISTINCT period_year_month FROM sales_history WHERE period_year_month IS NOT NULL ORDER BY period_year_month DESC'),
      dbAll('SELECT DISTINCT zone FROM sales_history WHERE zone IS NOT NULL AND zone != "" ORDER BY zone ASC'),
      dbAll('SELECT DISTINCT branch FROM visit_execution_logs WHERE branch IS NOT NULL AND branch != "" ORDER BY branch ASC'),
      dbAll('SELECT DISTINCT route FROM visit_execution_logs WHERE route IS NOT NULL AND route != "" ORDER BY route ASC'),
      dbAll('SELECT DISTINCT employee_name FROM visit_execution_logs WHERE employee_name IS NOT NULL AND employee_name != "" ORDER BY employee_name ASC'),
      dbAll('SELECT DISTINCT visit_status FROM visit_execution_logs WHERE visit_status IS NOT NULL AND visit_status != "" ORDER BY visit_status ASC'),
      dbAll('SELECT DISTINCT visit_date FROM visit_execution_logs WHERE visit_date IS NOT NULL AND visit_date != "0000-00-00" ORDER BY visit_date DESC'),
      dbAll('SELECT DISTINCT customer_type FROM visit_execution_logs WHERE customer_type IS NOT NULL AND customer_type != "" ORDER BY customer_type ASC'),
      dbAll('SELECT DISTINCT area FROM master_dealer_so_mapping WHERE area IS NOT NULL AND area != "" ORDER BY area ASC'),
      dbAll('SELECT DISTINCT region FROM master_dealer_so_mapping WHERE region IS NOT NULL AND region != "" ORDER BY region ASC'),
      dbAll('SELECT DISTINCT so_name FROM master_dealer_so_mapping WHERE so_name IS NOT NULL AND so_name != "" ORDER BY so_name ASC'),
      dbAll('SELECT DISTINCT zone FROM dealer_visit_targets WHERE zone IS NOT NULL AND zone != "" ORDER BY zone ASC'),
      dbAll('SELECT DISTINCT area FROM dealer_visit_targets WHERE area IS NOT NULL AND area != "" ORDER BY area ASC'),
      dbAll('SELECT DISTINCT so_name FROM dealer_visit_targets WHERE so_name IS NOT NULL AND so_name != "" ORDER BY so_name ASC'),
      dbAll('SELECT DISTINCT category FROM dealer_visit_targets WHERE category IS NOT NULL AND category != "" ORDER BY category ASC'),
      dbAll('SELECT DISTINCT dealer_status FROM dealer_visit_targets WHERE dealer_status IS NOT NULL AND dealer_status != "" ORDER BY dealer_status ASC')
    ]);

    res.json({
      dealerZones: dealerZones.map(r => r.zone),
      dealerRegions: dealerRegions.map(r => r.region),
      dealerAreas: dealerAreas.map(r => r.area),
      dealerTypes: dealerTypes.map(r => r.dealer_type),
      dealerStatuses: dealerStatuses.map(r => r.status),
      salesPeriods: salesPeriods.map(r => r.period_year_month),
      salesZones: salesZones.map(r => r.zone),
      logBranches: logBranches.map(r => r.branch),
      logRoutes: logRoutes.map(r => r.route),
      logEmployees: logEmployees.map(r => r.employee_name),
      logStatuses: logStatuses.map(r => r.visit_status),
      logVisitDates: logVisitDates.map(r => r.visit_date),
      logCustomerTypes: logCustomerTypes.map(r => r.customer_type),
      mappingAreas: mappingAreas.map(r => r.area),
      mappingRegions: mappingRegions.map(r => r.region),
      mappingSos: mappingSos.map(r => r.so_name),
      pjpZones: pjpZones.map(r => r.zone),
      pjpAreas: pjpAreas.map(r => r.area),
      pjpSos: pjpSos.map(r => r.so_name),
      pjpCategories: pjpCategories.map(r => r.category),
      pjpStatuses: pjpStatuses.map(r => r.dealer_status)
    });
  } catch (err) {
    console.error('Error fetching master filter options:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get Dealer to SO territory hierarchy mapping with rich field filters
 */
export async function getTerritoryMapping(req, res) {
  try {
    const { search, area, region, soName, strategy, custType, limit = 50, offset = 0 } = req.query;
    let sql = "SELECT m.*, d.dealer_type FROM master_dealer_so_mapping m LEFT JOIN master_dealers d ON m.dealer_id = d.id WHERE 1=1";
    let countSql = "SELECT COUNT(*) as total FROM master_dealer_so_mapping m LEFT JOIN master_dealers d ON m.dealer_id = d.id WHERE 1=1";
    const params = [];
    const countParams = [];

    if (custType && custType !== 'ALL') {
      if (custType === 'NON-STAR' || custType === 'NON_STAR') {
        sql += " AND (d.dealer_type = 'NON_STAR' OR d.dealer_type = 'NON-STAR')";
        countSql += " AND (d.dealer_type = 'NON_STAR' OR d.dealer_type = 'NON-STAR')";
      } else {
        sql += " AND d.dealer_type = ?";
        countSql += " AND d.dealer_type = ?";
        params.push(custType);
        countParams.push(custType);
      }
    }
    if (area && area !== 'ALL') {
      sql += ' AND m.area = ?';
      countSql += ' AND m.area = ?';
      params.push(area);
      countParams.push(area);
    }
    if (region && region !== 'ALL') {
      sql += ' AND m.region = ?';
      countSql += ' AND m.region = ?';
      params.push(region);
      countParams.push(region);
    }
    if (soName && soName !== 'ALL') {
      sql += ' AND m.so_name = ?';
      countSql += ' AND m.so_name = ?';
      params.push(soName);
      countParams.push(soName);
    }
    if (search) {
      sql += ' AND (m.dealer_name LIKE ? OR m.sap_code LIKE ? OR m.so_name LIKE ? OR m.so_emp_code LIKE ?)';
      countSql += ' AND (m.dealer_name LIKE ? OR m.sap_code LIKE ? OR m.so_name LIKE ? OR m.so_emp_code LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s);
      countParams.push(s, s, s, s);
    }

    sql += ' ORDER BY dealer_name ASC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const [rows, countObj] = await Promise.all([
      dbAll(sql, params),
      dbGet(countSql, countParams)
    ]);

    res.json({
      total: countObj?.total || 0,
      mappings: rows
    });
  } catch (err) {
    console.error('Error fetching territory mapping:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get Master Dealers list with rich field filters & pagination
 */
export async function getMasterDealers(req, res) {
  try {
    const { search, dealerType, status, area, region, zone, counterStrategy, limit = 50, offset = 0 } = req.query;
    let sql = `
      SELECT m.*, sm.so_name 
      FROM master_dealers m 
      LEFT JOIN (
        SELECT dealer_id, MAX(so_name) as so_name 
        FROM master_dealer_so_mapping 
        GROUP BY dealer_id
      ) sm ON m.id = sm.dealer_id 
      WHERE 1=1
    `;
    let countSql = 'SELECT COUNT(*) as total FROM master_dealers m WHERE 1=1';
    const params = [];
    const countParams = [];

    if (counterStrategy && counterStrategy !== 'ALL') {
      if (counterStrategy === 'PROSPECT') {
        sql += ' AND (m.counter_strategy = ? OR m.dealer_type = "PROSPECTIVE")';
        countSql += ' AND (m.counter_strategy = ? OR m.dealer_type = "PROSPECTIVE")';
      } else {
        sql += ' AND m.counter_strategy = ?';
        countSql += ' AND m.counter_strategy = ?';
      }
      params.push(counterStrategy);
      countParams.push(counterStrategy);
    }
    if (dealerType && dealerType !== 'ALL') {
      sql += ' AND dealer_type = ?';
      countSql += ' AND dealer_type = ?';
      params.push(dealerType);
      countParams.push(dealerType);
    }
    if (status && status !== 'ALL') {
      sql += ' AND status = ?';
      countSql += ' AND status = ?';
      params.push(status);
      countParams.push(status);
    }
    if (zone && zone !== 'ALL') {
      sql += ' AND zone = ?';
      countSql += ' AND zone = ?';
      params.push(zone);
      countParams.push(zone);
    }
    if (region && region !== 'ALL') {
      sql += ' AND region = ?';
      countSql += ' AND region = ?';
      params.push(region);
      countParams.push(region);
    }
    if (area && area !== 'ALL') {
      sql += ' AND area = ?';
      countSql += ' AND area = ?';
      params.push(area);
      countParams.push(area);
    }
    if (search) {
      sql += ' AND (dealer_name LIKE ? OR sap_code LIKE ? OR sfa_code LIKE ? OR rssd_code LIKE ? OR taluka LIKE ?)';
      countSql += ' AND (dealer_name LIKE ? OR sap_code LIKE ? OR sfa_code LIKE ? OR rssd_code LIKE ? OR taluka LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s, s);
      countParams.push(s, s, s, s, s);
    }

    sql += ' ORDER BY dealer_name ASC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const [rows, countObj] = await Promise.all([
      dbAll(sql, params),
      dbGet(countSql, countParams)
    ]);

    res.json({
      total: countObj?.total || 0,
      dealers: rows
    });
  } catch (err) {
    console.error('Error fetching master dealers:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get Sales History list with rich field filters & pagination
 */
export async function getSalesHistory(req, res) {
  try {
    const { search, period, zone, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT * FROM sales_history WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM sales_history WHERE 1=1';
    const params = [];
    const countParams = [];

    if (period && period !== 'ALL') {
      sql += ' AND period_year_month = ?';
      countSql += ' AND period_year_month = ?';
      params.push(period);
      countParams.push(period);
    }
    if (zone && zone !== 'ALL') {
      sql += ' AND zone = ?';
      countSql += ' AND zone = ?';
      params.push(zone);
      countParams.push(zone);
    }
    if (search) {
      sql += ' AND (sub_dealer_name LIKE ? OR linked_dealer_name LIKE ? OR sap_code LIKE ? OR rssd_code LIKE ? OR linked_dealer_code LIKE ?)';
      countSql += ' AND (sub_dealer_name LIKE ? OR linked_dealer_name LIKE ? OR sap_code LIKE ? OR rssd_code LIKE ? OR linked_dealer_code LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s, s);
      countParams.push(s, s, s, s, s);
    }

    sql += ' ORDER BY id DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const [rows, countObj] = await Promise.all([
      dbAll(sql, params),
      dbGet(countSql, countParams)
    ]);

    res.json({
      total: countObj?.total || 0,
      sales: rows
    });
  } catch (err) {
    console.error('Error fetching sales history:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get SFA Visit Execution Logs with rich field filters & pagination
 */
export async function getVisitExecutionLogs(req, res) {
  try {
    const { search, visitDate, employeeName, branch, route, visitStatus, customerType, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT * FROM visit_execution_logs WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM visit_execution_logs WHERE 1=1';
    const params = [];
    const countParams = [];

    if (visitDate && visitDate !== 'ALL') {
      sql += ' AND visit_date = ?';
      countSql += ' AND visit_date = ?';
      params.push(visitDate);
      countParams.push(visitDate);
    }
    if (employeeName && employeeName !== 'ALL') {
      sql += ' AND employee_name = ?';
      countSql += ' AND employee_name = ?';
      params.push(employeeName);
      countParams.push(employeeName);
    }
    if (branch && branch !== 'ALL') {
      sql += ' AND branch = ?';
      countSql += ' AND branch = ?';
      params.push(branch);
      countParams.push(branch);
    }
    if (route && route !== 'ALL') {
      sql += ' AND route = ?';
      countSql += ' AND route = ?';
      params.push(route);
      countParams.push(route);
    }
    if (visitStatus && visitStatus !== 'ALL') {
      sql += ' AND visit_status = ?';
      countSql += ' AND visit_status = ?';
      params.push(visitStatus);
      countParams.push(visitStatus);
    }
    if (customerType && customerType !== 'ALL') {
      sql += ' AND customer_type = ?';
      countSql += ' AND customer_type = ?';
      params.push(customerType);
      countParams.push(customerType);
    }
    if (search) {
      sql += ' AND (customer_name LIKE ? OR customer_code LIKE ? OR employee_name LIKE ? OR employee_code LIKE ? OR branch LIKE ? OR route LIKE ?)';
      countSql += ' AND (customer_name LIKE ? OR customer_code LIKE ? OR employee_name LIKE ? OR employee_code LIKE ? OR branch LIKE ? OR route LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s, s, s);
      countParams.push(s, s, s, s, s, s);
    }

    sql += ' ORDER BY visit_date DESC, id DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const [rows, countObj] = await Promise.all([
      dbAll(sql, params),
      dbGet(countSql, countParams)
    ]);

    res.json({
      total: countObj?.total || 0,
      logs: rows
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get Master Employees list with rich field filters & pagination
 */
export async function getMasterEmployees(req, res) {
  try {
    const { search, zone, region, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT * FROM master_employees WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM master_employees WHERE 1=1';
    const params = [];
    const countParams = [];

    if (zone && zone !== 'ALL') {
      sql += ' AND zone = ?';
      countSql += ' AND zone = ?';
      params.push(zone);
      countParams.push(zone);
    }
    if (region && region !== 'ALL') {
      sql += ' AND region = ?';
      countSql += ' AND region = ?';
      params.push(region);
      countParams.push(region);
    }
    if (search) {
      sql += ' AND (emp_name LIKE ? OR emp_code LIKE ? OR designation LIKE ?)';
      countSql += ' AND (emp_name LIKE ? OR emp_code LIKE ? OR designation LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s);
      countParams.push(s, s, s);
    }

    sql += ' ORDER BY emp_name ASC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const [rows, countObj] = await Promise.all([
      dbAll(sql, params),
      dbGet(countSql, countParams)
    ]);

    res.json({
      total: countObj?.total || 0,
      employees: rows
    });
  } catch (err) {
    console.error('Error fetching master employees:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Purge old data from the database
 */
export async function purgeOldData(req, res) {
  try {
    const tablesToPurge = [
      'upload_batches',
      'master_employees',
      'master_dealers',
      'master_dealer_so_mapping',
      'sales_history',
      'visit_execution_logs',
      'dealer_visit_targets',
      'djp_recommendations',
      'sales_plans',
      'sales_plan_details',
      'plan_approvals'
    ];

    for (const table of tablesToPurge) {
      await dbRun(`DELETE FROM ${table}`);
    }

    res.json({ message: 'Old data purged successfully from all master tables.' });
  } catch (err) {
    console.error('Error purging data:', err);
    res.status(500).json({ error: err.message });
  }
}
