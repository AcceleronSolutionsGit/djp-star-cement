import { generateFullPjpDjpSolution } from '../engines/djp-generator.engine.js';
import { calculatePJP } from '../engines/pjp/pjp.engine.js';
import { generateDealerTrace } from '../engines/pjp/pjp-validator.engine.js';
import { reconcileUniverse } from '../engines/pjp/reconciliation.service.js';
import { checkAllExcelInputsAvailable } from '../engines/pjp/data-loader.engine.js';
import { dbAll, dbGet } from '../config/database.js';
import XLSX from 'xlsx';

/**
 * Run canonical PJP calculation only (without DJP allocation).
 */
export async function calculatePjp(req, res) {
  try {
    const planMonth = req.body.planMonth || req.body.periodMonth;
    const cycleCode = req.body.cycleCode || 'C1';

    if (!planMonth || typeof planMonth !== 'string') {
      return res.status(400).json({ error: 'planMonth is required. Please specify the planning month in YYYY-MM format.' });
    }
    const match = planMonth.match(/^(\d{4})-(\d{2})$/);
    if (!match) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Expected format is YYYY-MM.` });
    }
    const mNum = parseInt(match[2], 10);
    if (mNum < 1 || mNum > 12) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Month must be between 01 and 12.` });
    }
    const periodMonth = planMonth;

    // Verify all 5 Excel files are available before calculating
    const inputCheck = await checkAllExcelInputsAvailable();
    if (!inputCheck.allAvailable) {
      return res.status(400).json({
        error: `Cannot generate DJP: All 5 Excel input files must be uploaded and validated first. Currently missing: ${inputCheck.missing.join(', ')}.`
      });
    }

    const result = await calculatePJP(periodMonth, cycleCode, { persist: true });

    res.json({
      message: 'PJP Calculation Complete',
      periodMonth,
      cycleCode,
      stats: result.stats,
      validation: {
        valid: result.validation.valid,
        totalErrors: result.validation.totalErrors,
        totalDuplicates: result.validation.totalDuplicates,
        // Only return first 50 errors to avoid huge payloads
        errors: result.validation.errors.slice(0, 50)
      }
    });
  } catch (err) {
    console.error('Error calculating PJP:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Generate PJP + DJP for all roles.
 */
export async function generateAllRolePlans(req, res) {
  try {
    const planMonth = req.body.planMonth || req.body.periodMonth;
    const cycleCode = req.body.cycleCode || 'C1';

    if (!planMonth || typeof planMonth !== 'string') {
      return res.status(400).json({ error: 'planMonth is required. Please specify the planning month in YYYY-MM format.' });
    }
    const match = planMonth.match(/^(\d{4})-(\d{2})$/);
    if (!match) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Expected format is YYYY-MM.` });
    }
    const mNum = parseInt(match[2], 10);
    if (mNum < 1 || mNum > 12) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Month must be between 01 and 12.` });
    }
    const periodMonth = planMonth;

    // Verify all 5 Excel files are available before calculating
    const inputCheck = await checkAllExcelInputsAvailable();
    if (!inputCheck.allAvailable) {
      return res.status(400).json({
        error: `Cannot generate DJP: All 5 Excel input files must be uploaded and validated first. Currently missing: ${inputCheck.missing.join(', ')}.`
      });
    }

    const result = await generateFullPjpDjpSolution(periodMonth, cycleCode);

    res.json({
      message: 'Multi-Role PJP & DJP Solution Generated Successfully',
      periodMonth,
      cycleCode,
      ...result
    });
  } catch (err) {
    console.error('Error generating multi-role DJP:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get PJP debug trace for a specific dealer.
 */
export async function getPjpDebug(req, res) {
  try {
    const { dealerCode } = req.params;
    const { periodMonth, cycleCode } = req.query;

    if (!dealerCode) {
      return res.status(400).json({ error: 'dealerCode is required' });
    }

    const pm = periodMonth || req.query.planMonth;
    if (!pm || !/^\d{4}-\d{2}$/.test(pm)) {
      return res.status(400).json({ error: 'periodMonth query parameter is required (YYYY-MM)' });
    }
    const cc = cycleCode || 'C1';

    const pjp = await calculatePJP(pm, cc, { persist: false, debug: true });
    const dealer = pjp.results.find(r =>
      r.dealerCode === dealerCode ||
      r.dealerCode === dealerCode.toUpperCase()
    );

    if (!dealer) {
      return res.status(404).json({ error: `Dealer ${dealerCode} not found in PJP results` });
    }

    const trace = generateDealerTrace(dealer);
    res.json({ dealer, trace });
  } catch (err) {
    console.error('Error getting PJP debug:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get dealer visit targets with pagination.
 */
export async function getDealerVisitTargets(req, res) {
  try {
    const { soEmpCode, soName, category, dealerStatus, custType, search, periodMonth, cycleCode, zone, area, limit, offset } = req.query;

    let sql = 'SELECT dvt.*, md.dealer_type FROM dealer_visit_targets dvt LEFT JOIN master_dealers md ON dvt.dealer_id = md.id WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM dealer_visit_targets dvt LEFT JOIN master_dealers md ON dvt.dealer_id = md.id WHERE 1=1';
    const params = [];
    const countParams = [];

    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle = cycleCode && cycleCode !== 'ALL' ? cycleCode : null;

    // Check if targetPeriod has records, if not fallback to latest period
    if (targetPeriod) {
      const exists = await dbGet('SELECT COUNT(*) as cnt FROM dealer_visit_targets WHERE period_month = ?', [targetPeriod]);
      if (!exists || exists.cnt === 0) {
        const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets ORDER BY period_month DESC LIMIT 1');
        if (latest) {
          targetPeriod = latest.period_month;
          if (!targetCycle) targetCycle = latest.cycle_code;
        }
      }
    } else {
      const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets ORDER BY period_month DESC LIMIT 1');
      if (latest) {
        targetPeriod = latest.period_month;
        if (!targetCycle) targetCycle = latest.cycle_code;
      }
    }

    if (custType && custType !== 'ALL') {
      if (custType === 'NON-STAR' || custType === 'NON_STAR') {
        sql += " AND (md.dealer_type = 'NON_STAR' OR md.dealer_type = 'NON-STAR')";
        countSql += " AND (md.dealer_type = 'NON_STAR' OR md.dealer_type = 'NON-STAR')";
      } else {
        sql += " AND md.dealer_type = ?";
        countSql += " AND md.dealer_type = ?";
        params.push(custType);
        countParams.push(custType);
      }
    }
    if (targetPeriod) {
      sql += ' AND dvt.period_month = ?';
      countSql += ' AND dvt.period_month = ?';
      params.push(targetPeriod);
      countParams.push(targetPeriod);
    }
    if (targetCycle) {
      sql += ' AND dvt.cycle_code = ?';
      countSql += ' AND dvt.cycle_code = ?';
      params.push(targetCycle);
      countParams.push(targetCycle);
    }
    if (zone && zone !== 'ALL') {
      sql += ' AND dvt.zone = ?';
      countSql += ' AND dvt.zone = ?';
      params.push(zone);
      countParams.push(zone);
    }
    if (area && area !== 'ALL') {
      sql += ' AND dvt.area = ?';
      countSql += ' AND dvt.area = ?';
      params.push(area);
      countParams.push(area);
    }
    if (soEmpCode && soEmpCode !== 'ALL') {
      sql += ' AND dvt.so_emp_code = ?';
      countSql += ' AND dvt.so_emp_code = ?';
      params.push(soEmpCode);
      countParams.push(soEmpCode);
    }
    if (soName && soName !== 'ALL') {
      sql += ' AND dvt.so_name = ?';
      countSql += ' AND dvt.so_name = ?';
      params.push(soName);
      countParams.push(soName);
    }
    if (category && category !== 'ALL') {
      sql += ' AND dvt.category = ?';
      countSql += ' AND dvt.category = ?';
      params.push(category);
      countParams.push(category);
    }
    if (dealerStatus && dealerStatus !== 'ALL') {
      sql += ' AND dvt.dealer_status = ?';
      countSql += ' AND dvt.dealer_status = ?';
      params.push(dealerStatus);
      countParams.push(dealerStatus);
    }
    if (search) {
      sql += ' AND (dvt.dealer_name LIKE ? OR dvt.sap_code LIKE ? OR dvt.area LIKE ? OR dvt.so_name LIKE ? OR dvt.zone LIKE ?)';
      countSql += ' AND (dvt.dealer_name LIKE ? OR dvt.sap_code LIKE ? OR dvt.area LIKE ? OR dvt.so_name LIKE ? OR dvt.zone LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s, s);
      countParams.push(s, s, s, s, s);
    }

    sql += ' ORDER BY dvt.category ASC, dvt.dealer_name ASC';

    const pageLimit = parseInt(limit || '50', 10);
    const pageOffset = parseInt(offset || '0', 10);
    sql += ' LIMIT ? OFFSET ?';
    params.push(pageLimit, pageOffset);

    const [targets, countObj] = await Promise.all([
      dbAll(sql, params),
      dbGet(countSql, countParams)
    ]);

    const formattedTargets = targets.map(t => {
      const soVisits = parseFloat(t.so_visits) || 0;
      const asmVisits = parseFloat(t.asm_visits) || 0;
      const rsmVisits = parseFloat(t.rsm_visits) || 0;
      const zhVisits = parseFloat(t.zh_visits) || 0;
      const totalVisits = t.total_visits !== undefined && t.total_visits !== null
        ? parseFloat(t.total_visits)
        : (soVisits + asmVisits + rsmVisits + zhVisits);

      const soVisitsPct = t.so_visits_pct !== undefined && t.so_visits_pct !== null
        ? parseFloat(t.so_visits_pct)
        : (totalVisits > 0 ? Math.round((soVisits / totalVisits) * 10000) / 100 : 0);

      const asmVisitsPct = t.asm_visits_pct !== undefined && t.asm_visits_pct !== null
        ? parseFloat(t.asm_visits_pct)
        : (totalVisits > 0 ? Math.round((asmVisits / totalVisits) * 10000) / 100 : 0);

      const rsmVisitsPct = t.rsm_visits_pct !== undefined && t.rsm_visits_pct !== null
        ? parseFloat(t.rsm_visits_pct)
        : (totalVisits > 0 ? Math.round((rsmVisits / totalVisits) * 10000) / 100 : 0);

      const zhVisitsPct = t.zh_visits_pct !== undefined && t.zh_visits_pct !== null
        ? parseFloat(t.zh_visits_pct)
        : (totalVisits > 0 ? Math.round((zhVisits / totalVisits) * 10000) / 100 : 0);

      return {
        ...t,
        total_visits: totalVisits,
        so_visits_pct: soVisitsPct,
        asm_visits_pct: asmVisitsPct,
        rsm_visits_pct: rsmVisitsPct,
        zh_visits_pct: zhVisitsPct
      };
    });

    res.json({ total: countObj?.total || formattedTargets.length, targets: formattedTargets });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getDjpPlan(req, res) {
  try {
    const { roleType, soEmpCode, empCode, periodMonth, cycleCode } = req.query;

    let sql = 'SELECT * FROM djp_recommendations WHERE 1=1';
    const params = [];

    if (roleType) {
      sql += ' AND role_type = ?';
      params.push(roleType);
    }
    if (soEmpCode) {
      sql += ' AND emp_code = ?';
      params.push(soEmpCode);
    }
    if (empCode) {
      sql += ' AND emp_code = ?';
      params.push(empCode);
    }
    if (periodMonth) {
      sql += ' AND period_month = ?';
      params.push(periodMonth);
    }
    if (cycleCode) {
      sql += ' AND cycle_code = ?';
      params.push(cycleCode);
    }

    sql += ' ORDER BY visit_date ASC, visit_sequence ASC';

    const plan = await dbAll(sql, params);
    res.json({ total: plan.length, plan });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

/**
 * Export the generated PJP_TRADE output as an Excel file with EXACTLY 16 columns.
 */
export async function exportPjpTradeExcel(req, res) {
  try {
    const { periodMonth, cycleCode } = req.query;

    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle = cycleCode && cycleCode !== 'ALL' ? cycleCode : null;

    if (!targetPeriod) {
      const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets WHERE period_month IS NOT NULL ORDER BY period_month DESC LIMIT 1');
      if (latest) {
        targetPeriod = latest.period_month;
        if (!targetCycle) targetCycle = latest.cycle_code || 'C1';
      }
    }

    let sql = `
      SELECT 
        dvt.*,
        dvt.sbg_block,
        dvt.dm_area,
        dvt.cust_type,
        dvt.priority_label,
        md.dealer_type,
        md.block as md_block
      FROM dealer_visit_targets dvt
      LEFT JOIN master_dealers md ON dvt.dealer_id = md.id
      WHERE 1=1
    `;
    const params = [];

    if (targetPeriod) {
      sql += ' AND dvt.period_month = ?';
      params.push(targetPeriod);
    }
    if (targetCycle) {
      sql += ' AND dvt.cycle_code = ?';
      params.push(targetCycle);
    }
    sql += ' ORDER BY dvt.zone ASC, dvt.category ASC, dvt.dealer_name ASC';

    let targets = await dbAll(sql, params);

    // Fallback: If nothing matched specific period/cycle, fetch all available targets
    if (!targets || targets.length === 0) {
      targets = await dbAll(`
        SELECT dvt.*, md.dealer_type, md.block
        FROM dealer_visit_targets dvt
        LEFT JOIN master_dealers md ON dvt.dealer_id = md.id
        ORDER BY dvt.zone ASC, dvt.category ASC, dvt.dealer_name ASC
      `);
    }

    if (!targets || targets.length === 0) {
      return res.status(404).json({ error: 'No PJP_TRADE data found. Please run DJP generation first.' });
    }

    // 2. Map strictly to the 16 requested columns
    const exportData = targets.map(t => {
      // Resolve Cust Type: Title Case ('Dealer' or 'Prospective')
      let rawType = String(t.cust_type || t.dealer_type || 'DEALER').toUpperCase();
      let custType = 'Dealer';
      if (rawType === 'PROSPECTIVE' || rawType === 'PROSPECT') {
        custType = 'Prospective';
      } else if (rawType === 'NON_STAR' || rawType === 'NON-STAR') {
        custType = 'Non-Star';
      }

      // Customer CODE: SAP if available, else SFA, else '-'.
      let custCode = t.sap_code || t.sfa_code || '-';

      // Block: MUST come from sbg_block (SBG authoritative) or prospect block, fallback '-'
      const block = t.sbg_block || t.block || '-';

      // Area: MUST come from dm_area (Dealer Mapping authoritative), fallback '-'
      const area = t.dm_area || t.area || '-';

      // Priority: numeric SO-wise priority rank (matching reference output)
      const priority = t.priority !== null && t.priority !== undefined ? Number(t.priority) : 1;

      const soVisits = parseFloat(t.so_visits) || 0;
      const asmVisits = parseFloat(t.asm_visits) || 0;
      const rsmVisits = parseFloat(t.rsm_visits) || 0;
      const zhVisits = parseFloat(t.zh_visits) || 0;

      return {
        'Zone': t.zone || '-',
        'Cust Type': custType,
        'Area': area,
        'Block': block,
        'ZONAL HEAD': t.zh_name || '-',
        'RSM': t.rsm_name || '-',
        'ASM': t.asm_name || '-',
        'SO/SE NAME': t.so_name || '-',
        'DEALER NAME': t.dealer_name || '-',
        'Customer CODE': custCode,
        'Priority': priority,
        'Category': t.dealer_status || '-',
        'No. of visits by SO': soVisits,
        'No. of visits by ASM': asmVisits,
        'Number of Visit by RSM': rsmVisits,
        'Number of Visit by ZH': zhVisits
      };
    });

    // 3. Create Workbook and Worksheet
    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'PJP_TRADE');

    // 4. Generate buffer
    const buf = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    // 5. Send as download
    const filename = `PJP_TRADE_${targetPeriod || '2026-06'}_${targetCycle || 'C1'}.xlsx`;
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);

  } catch (err) {
    console.error('Error exporting PJP_TRADE:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Export Master Report matching M_SAMPLE_EXPECTED.xlsx exactly (22 columns, sheet 'Report')
 */
export async function exportMasterExcel(req, res) {
  try {
    const { periodMonth, cycleCode } = req.query;
    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle = cycleCode && cycleCode !== 'ALL' ? cycleCode : 'C1';

    if (!targetPeriod) {
      const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets WHERE period_month IS NOT NULL ORDER BY period_month DESC LIMIT 1');
      if (latest) {
        targetPeriod = latest.period_month;
        if (latest.cycle_code) targetCycle = latest.cycle_code;
      } else {
        targetPeriod = '2026-06';
      }
    }

    let sql = `
      SELECT *
      FROM dealer_visit_targets
      WHERE period_month = ? AND cycle_code = ?
      ORDER BY sap_code ASC, id ASC
    `;
    let targets = await dbAll(sql, [targetPeriod, targetCycle]);

    if (!targets || targets.length === 0) {
      targets = await dbAll('SELECT * FROM dealer_visit_targets WHERE period_month = ? ORDER BY sap_code ASC, id ASC', [targetPeriod]);
    }

    if (!targets || targets.length === 0) {
      return res.status(400).json({ error: `No PJP Master data found for period ${targetPeriod}. Please upload all 5 Excel files and click 'Generate DJP Plans' first.` });
    }

    // Deduplicate by canonical dealer code to guarantee strict 1 Customer CODE -> 1 record
    const uniqueTargetsMap = new Map();
    for (const t of targets) {
      const code = t.sap_code || t.sfa_code;
      if (code) uniqueTargetsMap.set(code, t);
    }
    const uniqueTargets = [...uniqueTargetsMap.values()];

    const MASTER_SOURCES = [
      null, null, 'DLRWISE (WARROOM)', 'SALES MAPPING', 'SALES MAPPING', 'SALES MAPPING', 'DLRWISE (WARROOM)', null, 'SALES MAPPING', 'MARKET MAPPING (SBG)',
      'DLRWISE (WARROOM)', 'DLRWISE (WARROOM)', 'DLRWISE (WARROOM)', 'MARKET MAPPING (SBG)', 'DLRWISE (WARROOM)', null, 'DLRWISE (WARROOM)', 'DLRWISE (WARROOM)',
      'GET DATA FROM SOUMADEEP', 'DLRWISE (WARROOM)', null, null, null, null, null, null, 'PRIORITY', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null
    ];

    const MASTER_HEADERS = [
      'Cust Type', 'Sl.No.', 'Zone', 'ZONAL HEAD', 'RSM', 'ASM', 'AREA', 'Area Strategy', 'SO/SE  NAME', 'Block (Taluka)',
      'SFA CODE', 'Customer code', 'DEALER NAME', 'DLR COUNTER POTENTIAL ', 'Current Month Sales', 'Counter Share%', 'LYSM Sales', 'Previous Month Sales',
      'Last 6 months avg sales', 'DOA', 'Final Category', 'Rank based on counter potential (SO wise)',
      'A. Score based on counter potential (SO wise)\n(Out of 40)',
      'B. Score based on the category\n(Out of 40)',
      'C. Score based on the counter share (Out of 20)',
      'Total Score\n(A+B+C) \n(out of 100)',
      'Rank based on Total score\n(SO wise)',
      'Number of Visits by SO/SR (Based on Percentile)',
      'Number of visits by ASM (Based on Percentile)',
      'Number of Visits by RSM (based on percentile) ',
      'Number of visits by ZH (Based on percentile)',
      'Final volume',
      'Category based on percentile',
      'Area Volume',
      'Area Rank',
      'Area Percentile Based on Total Volume of Sales',
      "Is 'Need to grow'?",
      'Area Potential',
      'Area rank based on potential',
      'Area percentile based on potential',
      'Concat Category',
      'Concat'
    ];

    const masterRows = uniqueTargets.map((t, idx) => {
      const custType = t.cust_type || (t.dealer_type === 'PROSPECTIVE' ? 'NON STAR' : 'DEALER');
      const slNo = idx + 1;
      const zone = t.zone || '-';
      const zh = t.zh_name || '-';
      const rsm = t.rsm_name || '-';
      const asm = t.asm_name || '-';
      const area = t.dm_area || t.area || '-';
      const areaStrategy = '-';
      const soName = t.so_name || '-';
      const block = t.sbg_block || t.block || '-';
      const sfaCode = t.sfa_code || '-';
      const customerCode = t.sap_code || t.sfa_code || '-';
      const dealerName = t.dealer_name || '-';
      const potential = (t.sbg_potential !== null && t.sbg_potential !== undefined)
        ? Number(t.sbg_potential)
        : ((t.potential !== null && t.potential !== undefined) ? Number(t.potential) : null);
      const currSales = Number(t.current_sales) || 0;
      const counterShare = (potential && potential > 0) ? Number(t.counter_share || (currSales / potential)) : '-';
      const lysmSales = Number(t.lysm_sales) || 0;
      const prevSales = Number(t.previous_sales) || 0;
      const avg6m = Number(t.rsar_six_month_avg) || Number(t.dp_six_month_avg) || 0;
      const doa = t.doa || '-';
      const finalCategory = t.dealer_status || '-';
      const potRank = (potential && potential > 0) ? (t.potential_rank || 1) : '-';
      const scoreA = (potential && potential > 0) ? (Number(t.score_a) || 0) : '-';
      const scoreB = t.score_b !== null && t.score_b !== undefined ? Number(t.score_b) : 0;
      const scoreC = (potential && potential > 0) ? (Number(t.score_c) || 0) : '-';
      const totalScore = Number(t.total_score) || 0;
      const priorityRank = t.priority || 1;
      const soVisits = Number(t.so_visits) || 0;
      const asmVisits = Number(t.asm_visits) || 0;
      const rsmVisits = Number(t.rsm_visits) || 0;
      const zhVisits = Number(t.zh_visits) || 0;
      const finalVolume = Number(t.final_volume) || 0;
      const grade = t.category || t.grade || '-';
      const areaVolume = Number(t.area_volume) || 0;
      const areaRank = t.area_volume_rank || 1;
      const areaVolPct = Number(t.area_volume_percentile) || 0;
      const needToGrow = t.need_to_grow ? 'Yes' : 'No';
      const areaPotential = Number(t.area_potential) || 0;
      const areaPotRank = t.area_potential_rank || 1;
      const areaPotPct = Number(t.area_potential_percentile) || 0;
      const concatCategory = grade && grade !== '-' ? `${finalCategory}-${grade}` : finalCategory;
      const concat = `${dealerName}-${soName}-${finalCategory}`;

      return [
        custType, slNo, zone, zh, rsm, asm, area, areaStrategy, soName, block,
        sfaCode, customerCode, dealerName, potential ?? '-', currSales, counterShare, lysmSales, prevSales,
        avg6m, doa, finalCategory, potRank, scoreA, scoreB, scoreC, totalScore,
        priorityRank, soVisits, asmVisits, rsmVisits, zhVisits, finalVolume,
        grade, areaVolume, areaRank, areaVolPct, needToGrow, areaPotential,
        areaPotRank, areaPotPct, concatCategory, concat
      ];
    });

    const worksheetData = [
      new Array(42).fill(null),
      new Array(42).fill(null),
      MASTER_SOURCES,
      MASTER_HEADERS,
      ...masterRows
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Master');

    const buf = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    const filename = `M_${targetPeriod}_${targetCycle}.xlsx`;
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
  } catch (err) {
    console.error('Error exporting Master report:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Export Visits Report matching visits-To Be Achieved.xlsx reference format.
 * 
 * Reference format (verified from actual visits-To Be Achieved.xlsx):
 *   Sheet name: 'Visits'
 *   Row 1: blank
 *   Row 2: headers
 *   Row 3+: data
 * 
 * Columns (20 total):
 *   concat | Zone | Cust Type | Area | Block | ZONAL HEAD | RSM | ASM | SO/SE  NAME |
 *   DEALER NAME | Customer CODE (= SFA CODE) | Priority (numeric SO-wise rank) | Category |
 *   No. of visits by SO | No. of visits by ASM | Number of Visit by RSM | Number of Visit by ZH |
 *   Date of Visit 1 | Date of Visit 2 | Date of Visit 3
 * 
 * Rules:
 *   - Churn dealers EXCLUDED (no visits assigned)
 *   - Customer CODE = SFA CODE (not SAP code)
 *   - Priority = numeric priorityRank (SO-wise rank, e.g. 1, 2, 3...)
 */
export async function exportVisitsExcel(req, res) {
  try {
    const { periodMonth, cycleCode } = req.query;
    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle = cycleCode && cycleCode !== 'ALL' ? cycleCode : 'C1';

    if (!targetPeriod) {
      const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets WHERE period_month IS NOT NULL ORDER BY period_month DESC LIMIT 1');
      if (latest) {
        targetPeriod = latest.period_month;
        if (latest.cycle_code) targetCycle = latest.cycle_code;
      } else {
        targetPeriod = '2026-06';
      }
    }

    let targets = await dbAll(
      'SELECT * FROM dealer_visit_targets WHERE period_month = ? AND cycle_code = ? ORDER BY zone ASC, area ASC, so_name ASC, dealer_name ASC',
      [targetPeriod, targetCycle]
    );

    if (!targets || targets.length === 0) {
      targets = await dbAll(
        'SELECT * FROM dealer_visit_targets WHERE period_month = ? ORDER BY zone ASC, area ASC, so_name ASC, dealer_name ASC',
        [targetPeriod]
      );
    }

    if (!targets || targets.length === 0) {
      return res.status(400).json({ error: `No PJP Visits data found for period ${targetPeriod}. Please upload all 5 Excel files and click 'Generate DJP Plans' first.` });
    }

    const uniqueTargetsMap = new Map();
    for (const t of targets) {
      const code = t.sfa_code || t.sap_code;
      if (code) uniqueTargetsMap.set(code, t);
    }
    const uniqueTargets = [...uniqueTargetsMap.values()];

    const VISIT_HEADERS = [
      'concat', 'Zone', 'Cust Type', 'Area', 'Block', 'ZONAL HEAD', 'RSM', 'ASM', 'SO/SE  NAME',
      'DEALER NAME', 'Customer CODE', 'Priority', 'Category',
      'No. of visits by SO', 'No. of visits by ASM', 'Number of Visit by RSM', 'Number of Visit by ZH',
      'Date of Visit 1', 'Date of Visit 2', 'Date of Visit 3'
    ];

    const reportRows = [];

    for (const t of uniqueTargets) {
      const dealerStatus = t.dealer_status || '';
      if (dealerStatus === 'Churn') continue;

      const soVisits = parseFloat(t.so_visits) || 0;
      const asmVisits = parseFloat(t.asm_visits) || 0;
      const rsmVisits = parseFloat(t.rsm_visits) || 0;
      const zhVisits = parseFloat(t.zh_visits) || 0;

      if (soVisits === 0 && asmVisits === 0 && rsmVisits === 0 && zhVisits === 0) continue;

      const customerCode = t.sfa_code || t.sap_code || '';

      let custType = t.cust_type || 'DEALER';
      if (custType.toUpperCase() === 'NON_STAR' || custType.toUpperCase() === 'NON-STAR') {
        custType = 'NON STAR';
      } else if (custType.toUpperCase() === 'PROSPECTIVE') {
        custType = 'Prospective';
      } else if (custType.toUpperCase() === 'STAR') {
        custType = 'DEALER';
      }

      const priority = t.priority || 0;

      reportRows.push([
        null,
        t.zone || '',
        custType,
        t.dm_area || t.area || '',
        t.sbg_block || t.block || '',
        t.zh_name || '',
        t.rsm_name || '',
        t.asm_name || '',
        t.so_name || '',
        t.dealer_name || '',
        customerCode,
        priority,
        dealerStatus,
        soVisits,
        asmVisits,
        rsmVisits,
        zhVisits,
        null,
        null,
        null
      ]);
    }

    const worksheetData = [
      new Array(20).fill(null),
      VISIT_HEADERS,
      ...reportRows
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Visits');

    const exportBuf = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    const visitsFilename = `visits-To_Be_Achieved_${targetPeriod}_${targetCycle}.xlsx`;
    res.setHeader('Content-Disposition', `attachment; filename="${visitsFilename}"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(exportBuf);
  } catch (err) {
    console.error('Error exporting Visits report:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Return internal multi-source reconciliation report and diagnostics
 */
export async function getReconciliationDiagnostics(req, res) {
  try {
    const reportMonth = req.query.periodMonth || '2026-06';
    const cycleCode = req.query.cycleCode || 'C1';
    const result = await reconcileUniverse({ reportMonth, cycleCode });
    res.json(result);
  } catch (err) {
    console.error('Error getting reconciliation:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Check readiness of all 5 required Excel input documents.
 */
export async function getInputReadiness(req, res) {
  try {
    const status = await checkAllExcelInputsAvailable();
    res.json(status);
  } catch (err) {
    console.error('Error getting input readiness:', err);
    res.status(500).json({ error: err.message });
  }
}

