import { AutoPlanGenerator } from '../engines/autoPlanGenerator.js';
import { DealerMappingEngine } from '../engines/dealerMappingEngine.js';
import { dbAll, dbRun, dbGet } from '../config/database.js';

export async function generateAutoPlan(req, res) {
  try {
    const planMonth = req.body.planMonth || req.body.periodMonth;
    const { empCode, role, cycleCode } = req.body;

    if (!empCode) {
      return res.status(400).json({ error: 'empCode is required.' });
    }
    if (!planMonth || typeof planMonth !== 'string') {
      return res.status(400).json({ error: 'planMonth is required. Please specify the planning month in YYYY-MM format.' });
    }
    const match = planMonth.match(/^(\d{4})-(\d{2})$/);
    if (!match) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Expected format is YYYY-MM.` });
    }
    const mNum = parseInt(match[2], 10);
    if (mNum < 1 || mNum > 12) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Month must be between 01 and 12.` });
    }

    const generator = new AutoPlanGenerator();
    const result = await generator.generatePlan(empCode, planMonth, role || 'SO', cycleCode || 'C1');
    
    res.json(result);
  } catch (err) {
    console.error('Error generating auto plan:', err);
    res.status(500).json({ error: err.message });
  }
}

export async function runDealerMapping(req, res) {
  try {
    const engine = new DealerMappingEngine();
    const result = await engine.runMappingProcess();
    res.json(result);
  } catch (err) {
    console.error('Error running dealer mapping:', err);
    res.status(500).json({ error: err.message });
  }
}

export async function submitPlan(req, res) {
  try {
    const { planId } = req.body;
    if (!planId) return res.status(400).json({ error: 'planId is required.' });

    await dbRun('UPDATE sales_plans SET status = "SUBMITTED", submitted_at = CURRENT_TIMESTAMP WHERE id = ?', [planId]);
    res.json({ success: true, message: `Plan ${planId} submitted for approval.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function approvePlan(req, res) {
  try {
    const { planId, managerEmpCode, action, remarks } = req.body; // action: 'APPROVED' or 'REJECTED'
    if (!planId || !managerEmpCode || !action) {
      return res.status(400).json({ error: 'planId, managerEmpCode, and action are required.' });
    }

    await dbRun(
      'UPDATE sales_plans SET status = ?, approved_by = ?, approved_at = CURRENT_TIMESTAMP, remarks = ? WHERE id = ?',
      [action, managerEmpCode, remarks || '', planId]
    );

    await dbRun(
      'INSERT INTO plan_approvals (plan_id, action_by, action_type, remarks) VALUES (?, ?, ?, ?)',
      [planId, managerEmpCode, action, remarks || '']
    );

    res.json({ success: true, message: `Plan ${planId} ${action.toLowerCase()}.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getPlans(req, res) {
  try {
    const { empCode, role } = req.query;
    let query = 'SELECT * FROM sales_plans WHERE 1=1';
    const params = [];
    if (empCode && empCode !== 'ALL') {
      query += ' AND emp_code = ?';
      params.push(empCode);
    }
    query += ' ORDER BY created_at DESC';
    const plans = await dbAll(query, params);
    res.json({ plans });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getPlanDetails(req, res) {
  try {
    const { planId } = req.params;
    const details = await dbAll('SELECT * FROM sales_plan_details WHERE plan_id = ? ORDER BY visit_date ASC, sequence ASC', [planId]);
    res.json({ details });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getAllEmployees(req, res) {
  try {
    const { role } = req.query;

    // 1. Fetch from master_employees safely
    let empTable = [];
    try {
      empTable = await dbAll("SELECT id, emp_code, emp_name, role, designation, zone, region FROM master_employees");
    } catch (e) {
      console.warn('Could not query master_employees:', e.message);
    }
    
    // 2. Fetch distinct SOs, ASMs, RSMs, ZHs from dealer_visit_targets & master_dealer_so_mapping
    const [soList, asmList, rsmList, zhList] = await Promise.all([
      dbAll(`SELECT DISTINCT 
               COALESCE(NULLIF(TRIM(so_emp_code), ''), NULLIF(TRIM(so_name), '')) as emp_code,
               so_name as emp_name, 
               'SO' as role, 
               area, 
               zone as region 
             FROM dealer_visit_targets 
             WHERE so_name IS NOT NULL AND TRIM(so_name) != ''`),
      dbAll(`SELECT DISTINCT 
               COALESCE(NULLIF(TRIM(asm_code), ''), NULLIF(TRIM(asm_name), '')) as emp_code,
               asm_name as emp_name, 
               'ASM' as role, 
               area, 
               zone as region 
             FROM dealer_visit_targets 
             WHERE asm_name IS NOT NULL AND TRIM(asm_name) != ''`),
      dbAll(`SELECT DISTINCT 
               NULLIF(TRIM(rsm_name), '') as emp_code,
               rsm_name as emp_name, 
               'RSM' as role, 
               area, 
               zone as region 
             FROM dealer_visit_targets 
             WHERE rsm_name IS NOT NULL AND TRIM(rsm_name) != ''`),
      dbAll(`SELECT DISTINCT 
               NULLIF(TRIM(zh_name), '') as emp_code,
               zh_name as emp_name, 
               'ZH' as role, 
               area, 
               zone as region 
             FROM dealer_visit_targets 
             WHERE zh_name IS NOT NULL AND TRIM(zh_name) != ''`)
    ]);

    const combined = new Map();

    // Add from master_employees first
    for (const e of empTable) {
      if (e.emp_name) {
        const key = `${e.role || 'SO'}_${e.emp_code || e.emp_name}`;
        combined.set(key, {
          emp_code: e.emp_code || e.emp_name,
          emp_name: e.emp_name,
          role: e.role || 'SO',
          area: e.area || null,
          region: e.region || null
        });
      }
    }

    // Merge from target hierarchy lists
    for (const list of [soList, asmList, rsmList, zhList]) {
      for (const e of list) {
        if (!e.emp_name) continue;
        const key = `${e.role}_${e.emp_code || e.emp_name}`;
        if (!combined.has(key)) {
          combined.set(key, {
            emp_code: e.emp_code || e.emp_name,
            emp_name: e.emp_name,
            role: e.role,
            area: e.area || null,
            region: e.region || null
          });
        }
      }
    }

    let result = Array.from(combined.values());

    if (role && role !== 'ALL') {
      result = result.filter(e => e.role === role);
    }

    result.sort((a, b) => (a.emp_name || '').localeCompare(b.emp_name || ''));

    res.json({ employees: result });
  } catch (err) {
    console.error('Error in getAllEmployees:', err);
    res.status(500).json({ error: err.message });
  }
}

export async function addPlanVisit(req, res) {
  try {
    const { planId, visitDate, dealerId, dealerSapCode, dealerName, dealerType, purposeOfVisit } = req.body;
    const plan = await dbAll('SELECT status FROM sales_plans WHERE id = ?', [planId]);
    if (!plan || plan.length === 0 || plan[0].status !== 'DRAFT') {
      return res.status(400).json({ error: 'Only DRAFT plans can be edited.' });
    }

    // Constraint 1: Maximum 8 visits in a day
    const dayVisits = await dbAll(
      'SELECT id, dealer_id, dealer_sap_code, dealer_name FROM sales_plan_details WHERE plan_id = ? AND visit_date = ?',
      [planId, visitDate]
    );

    if (dayVisits.length >= 8) {
      return res.status(400).json({ error: 'Daily limit reached: Maximum 8 visits allowed per day.' });
    }

    // Constraint 2: Different customers in a day
    const alreadyScheduled = dayVisits.some(v => 
      (dealerId && v.dealer_id === dealerId) || 
      (dealerSapCode && v.dealer_sap_code === dealerSapCode) || 
      (dealerName && v.dealer_name.trim().toLowerCase() === dealerName.trim().toLowerCase())
    );

    if (alreadyScheduled) {
      return res.status(400).json({ error: 'Customer already scheduled on this day. Each visit in a day must be to a different customer.' });
    }

    const nextSeq = dayVisits.length + 1;
    const result = await dbRun(
      `INSERT INTO sales_plan_details (plan_id, visit_date, dealer_id, dealer_sap_code, dealer_name, dealer_type, purpose_of_visit, sequence) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [planId, visitDate, dealerId, dealerSapCode, dealerName, dealerType || 'DEALER', purposeOfVisit || 'Routine Visit', nextSeq]
    );
    res.json({ success: true, message: 'Visit added successfully.', detailId: result.lastID || result.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function removePlanVisit(req, res) {
  try {
    const { detailId } = req.params;
    const detail = await dbAll('SELECT plan_id FROM sales_plan_details WHERE id = ?', [detailId]);
    if (detail.length > 0) {
      const plan = await dbAll('SELECT status FROM sales_plans WHERE id = ?', [detail[0].plan_id]);
      if (plan.length > 0 && plan[0].status !== 'DRAFT') {
        return res.status(400).json({ error: 'Only DRAFT plans can be edited.' });
      }
    }
    await dbRun('DELETE FROM sales_plan_details WHERE id = ?', [detailId]);
    res.json({ success: true, message: 'Visit removed successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function movePlanVisit(req, res) {
  try {
    const { detailId, newDate } = req.body;
    const detail = await dbAll('SELECT plan_id FROM sales_plan_details WHERE id = ?', [detailId]);
    if (detail.length > 0) {
      const plan = await dbAll('SELECT status FROM sales_plans WHERE id = ?', [detail[0].plan_id]);
      if (plan.length > 0 && plan[0].status !== 'DRAFT') {
        return res.status(400).json({ error: 'Only DRAFT plans can be edited.' });
      }
    }
    await dbRun('UPDATE sales_plan_details SET visit_date = ? WHERE id = ?', [newDate, detailId]);
    res.json({ success: true, message: 'Visit moved successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getDealersForSO(req, res) {
  try {
    const { empCode, role } = req.query;
    if (!empCode) return res.status(400).json({ error: 'empCode is required' });

    let roleField = 'so_name';
    let codeField = 'so_emp_code';
    if (role === 'ASM') { roleField = 'asm_name'; codeField = 'asm_code'; }
    else if (role === 'RSM') { roleField = 'rsm_name'; codeField = 'rsm_name'; }
    else if (role === 'ZH') { roleField = 'zh_name'; codeField = 'zh_name'; }

    const dealers = await dbAll(
      `SELECT DISTINCT dealer_id, COALESCE(sap_code, sfa_code) as sap_code, dealer_name 
       FROM dealer_visit_targets 
       WHERE ${codeField} = ? OR ${roleField} = ? OR ${roleField} LIKE ?
       ORDER BY dealer_name ASC`,
      [empCode, empCode, `%${empCode}%`]
    );

    res.json({ dealers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function deletePlan(req, res) {
  try {
    const { planId } = req.params;
    if (!planId) return res.status(400).json({ error: 'planId is required' });
    
    await dbRun('DELETE FROM sales_plan_details WHERE plan_id = ?', [planId]);
    await dbRun('DELETE FROM plan_approvals WHERE plan_id = ?', [planId]);
    await dbRun('DELETE FROM sales_plans WHERE id = ?', [planId]);
    
    res.json({ success: true, message: 'Plan deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function bulkDeletePlans(req, res) {
  try {
    const { planIds } = req.body;
    if (!planIds || !Array.isArray(planIds) || planIds.length === 0) {
      return res.status(400).json({ error: 'planIds array is required' });
    }

    const placeholders = planIds.map(() => '?').join(',');
    await dbRun(`DELETE FROM sales_plan_details WHERE plan_id IN (${placeholders})`, planIds);
    await dbRun(`DELETE FROM plan_approvals WHERE plan_id IN (${placeholders})`, planIds);
    await dbRun(`DELETE FROM sales_plans WHERE id IN (${placeholders})`, planIds);

    res.json({ success: true, message: `Successfully deleted ${planIds.length} plans.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
