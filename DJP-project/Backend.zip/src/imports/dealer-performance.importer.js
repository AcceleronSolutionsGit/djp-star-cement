import XLSX from 'xlsx';
import { dbRun, dbGet } from '../config/database.js';
import { normalizeCode } from '../engines/normalization.engine.js';
import { parseMonthKey } from './sales-history.importer.js';
import path from 'path';

/**
 * Dealer Performance Importer
 *
 * CRITICAL: This importer writes to dealer_performance_history ONLY.
 * It must NEVER write to sales_history (RSAR table).
 *
 * This ensures complete separation:
 *   sales_history            ← RSAR data only
 *   dealer_performance_history ← Dealer Performance data only
 *
 * The PJP engine reads these as two independent sources:
 *   rsarSixMonthAverage   ← from sales_history
 *   dpSixMonthAverage     ← from dealer_performance_history
 */

function normalizeHeader(h) {
  if (!h) return '';
  return String(h).trim().toLowerCase().replace(/[\r\n]+/g, ' ').replace(/[_\-]+/g, ' ').replace(/\s+/g, ' ');
}

export async function importDealerPerformance(filePath, batchCode = null) {
  console.log(`[DEALER_PERFORMANCE] Processing from: ${filePath}`);
  console.log(`[DEALER_PERFORMANCE] Writing to dealer_performance_history (NOT sales_history)`);
  const sourceFileName = path.basename(filePath);
  const workbook = XLSX.readFile(filePath, { cellDates: true });
  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  const rawRows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null });

  if (!rawRows || rawRows.length < 2) {
    throw new Error(`[DEALER_PERFORMANCE] File is empty or contains no data.`);
  }

  let headerRowIdx = -1;
  let headers = [];

  for (let i = 0; i < Math.min(20, rawRows.length); i++) {
    const row = rawRows[i];
    if (!row) continue;
    const normalized = row.map(normalizeHeader);
    if (
      normalized.some(h => h === 'customer code' || h === 'dealer name' || h === 'dealers name' || h === 'sap code' || h === 'sap' || h === 'account name') &&
      normalized.some(h => h.includes('26') || h.includes('25') || h.includes('prev year') || h.includes('sales') || h.includes('sale') || h.includes('jan') || h.includes('jun'))
    ) {
      headerRowIdx = i;
      headers = normalized;
      break;
    }
  }

  if (headerRowIdx === -1) {
    throw new Error(`[DEALER_PERFORMANCE] Could not find valid header row in: ${sourceFileName}`);
  }

  // Map header columns — prefer explicit SAP column over SFA/generic code
  const sapIdx = headers.findIndex(h => h === 'sap' || h === 'sap code' || h === 'customer code');
  const sfaIdx = headers.findIndex(h => h === 'dealer code' || h === 'code' || h === 'sfa code');
  const codeIdx = sapIdx !== -1 ? sapIdx : sfaIdx;
  const nameIdx = headers.findIndex(h => h === 'dealers name' || h === 'dealer name' || h === 'customer name' || h === 'account name');
  const areaIdx = headers.findIndex(h => h === 'area' || h === 'branch');
  const regionIdx = headers.findIndex(h => h === 'region' || h === 'zone');
  const doaIdx = headers.findIndex(h => h === 'doa' || h === 'dealer start date');

  // Identify monthly columns dynamically
  const monthMap = []; // Array of { colIdx, periodYM }
  const prevMonthNames = {
    'prev year jan': '2025-01',
    'prev year feb': '2025-02',
    'prev year mar': '2025-03',
    'prev year apr': '2025-04',
    'prev year may': '2025-05',
    'prev year jun': '2025-06',
    'prev year jul': '2025-07',
    'prev year aug': '2025-08',
    'prev year sep': '2025-09',
    'prev year oct': '2025-10',
    'prev year nov': '2025-11',
    'prev year dec': '2025-12'
  };

  for (let c = 0; c < headers.length; c++) {
    const h = headers[c];
    if (c === codeIdx || c === nameIdx || c === sfaIdx) continue;

    if (prevMonthNames[h]) {
      monthMap.push({ colIdx: c, periodYM: prevMonthNames[h] });
      continue;
    }

    const parsedYM = parseMonthKey(rawRows[headerRowIdx][c]);
    if (parsedYM) {
      monthMap.push({ colIdx: c, periodYM: parsedYM });
    }
  }

  if (monthMap.length === 0) {
    throw new Error(`[DEALER_PERFORMANCE] No monthly columns found. Expected columns like Jan-26, Feb-26, etc.`);
  }

  let rowsRead = 0;
  let recordsInserted = 0;
  const errors = [];
  const warnings = [];

  const avgColIdx = headers.findIndex(h => h.includes('last 6 month') || h.includes('6 month avg') || h.includes('6m avg'));

  for (let i = headerRowIdx + 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    if (!row || row.every(c => c === null || c === undefined || String(c).trim() === '')) continue;
    rowsRead++;

    const sapCode = normalizeCode(sapIdx !== -1 ? row[sapIdx] : null);
    const sfaCode = normalizeCode(sfaIdx !== -1 ? row[sfaIdx] : null);
    const primaryCode = sapCode || sfaCode;
    const dealerName = nameIdx !== -1 ? String(row[nameIdx] || '').trim() : null;
    const rowArea = areaIdx !== -1 && row[areaIdx] ? String(row[areaIdx]).trim() : '-';
    const rowRegion = regionIdx !== -1 && row[regionIdx] ? String(row[regionIdx]).trim() : '-';
    const rawDoa = doaIdx !== -1 && row[doaIdx] ? String(row[doaIdx]).trim() : '-';

    if (!primaryCode && !dealerName) continue;

    // Check if dealer exists in master_dealers; if absent from Dealer Mapping & SBG, onboard with '-'
    const existingDealer = await dbGet(
      'SELECT id FROM master_dealers WHERE (sap_code = ? AND sap_code IS NOT NULL) OR (sfa_code = ? AND sfa_code IS NOT NULL) LIMIT 1',
      [primaryCode, primaryCode]
    );

    if (!existingDealer && primaryCode) {
      await dbRun(
        `INSERT INTO master_dealers (
          sap_code, sfa_code, dealer_name, dealer_type, status,
          area, dm_area, zone, region, doa,
          so_name, so_emp_code, asm_name, asm_code, rsm_name, rsm_code, zh_name, zh_code,
          block, sbg_block, sbg_potential, counter_potential,
          sbg_status, dp_status
        ) VALUES (
          ?, ?, ?, 'STAR', 'ACTIVE',
          ?, ?, ?, ?, ?,
          '-', '-', '-', '-', '-', '-', '-', '-',
          '-', '-', NULL, 0,
          'SBG_NOT_FOUND', 'DP_MATCHED'
        )`,
        [
          sapCode || null,
          sfaCode || null,
          dealerName || null,
          rowArea,
          rowArea,
          rowRegion,
          rowRegion,
          rawDoa
        ]
      );
    }

    // Capture explicit 6-Month Average column if present
    if (avgColIdx !== -1) {
      const avgVal = row[avgColIdx];
      if (avgVal !== null && avgVal !== undefined && String(avgVal).trim() !== '' && String(avgVal).trim() !== '-') {
        const avgQty = parseFloat(avgVal);
        if (!isNaN(avgQty)) {
          const existingAvg = await dbGet(
            'SELECT id FROM dealer_performance_history WHERE sap_code = ? AND period_year_month = "6M_AVG" LIMIT 1',
            [sapCode]
          );
          if (existingAvg) {
            await dbRun(
              'UPDATE dealer_performance_history SET quantity_mt = ?, dealer_name = COALESCE(?, dealer_name), batch_code = ? WHERE id = ?',
              [avgQty, dealerName, batchCode, existingAvg.id]
            );
          } else {
            await dbRun(
              'INSERT INTO dealer_performance_history (sap_code, dealer_name, period_year_month, quantity_mt, batch_code) VALUES (?, ?, "6M_AVG", ?, ?)',
              [sapCode || null, dealerName || null, avgQty, batchCode]
            );
          }
        }
      }
    }

    const seenInRow = new Map();

    for (const { colIdx, periodYM } of monthMap) {
      const val = row[colIdx];
      if (val === null || val === undefined || String(val).trim() === '' || String(val).trim() === '-') continue;
      const quantity = parseFloat(val);
      if (isNaN(quantity)) continue;

      if (!seenInRow.has(periodYM) || quantity > (seenInRow.get(periodYM) || 0)) {
        seenInRow.set(periodYM, quantity);
      }
    }

    for (const [periodYM, quantity] of seenInRow.entries()) {
      // ── WRITE TO dealer_performance_history ONLY (NOT sales_history) ──
      const existing = await dbGet(
        'SELECT id FROM dealer_performance_history WHERE sap_code = ? AND period_year_month = ? LIMIT 1',
        [sapCode, periodYM]
      );
      if (existing) {
        await dbRun(
          'UPDATE dealer_performance_history SET quantity_mt = ?, dealer_name = COALESCE(?, dealer_name), batch_code = ? WHERE id = ?',
          [quantity, dealerName, batchCode, existing.id]
        );
      } else {
        await dbRun(
          `INSERT INTO dealer_performance_history
           (sap_code, dealer_name, period_year_month, quantity_mt, batch_code)
           VALUES (?, ?, ?, ?, ?)`,
          [sapCode || null, dealerName || null, periodYM, quantity, batchCode]
        );
      }
      recordsInserted++;
    }
  }

  const monthsFound = [...new Set(monthMap.map(m => m.periodYM))].sort();

  if (monthsFound.length < 6) {
    const warnMsg = `[DEALER_PERFORMANCE] Warning: Only ${monthsFound.length} of 6 required months found (${monthsFound.join(', ')}). Full 6-month average will be calculated only on available months. Never borrowing from RSAR.`;
    console.warn(warnMsg);
    warnings.push({
      message: warnMsg,
      monthsFound,
      monthsExpected: 6,
      canComputeSixMonthAvg: false
    });
  }

  console.log(`[DEALER_PERFORMANCE] Complete: ${recordsInserted} records in dealer_performance_history across ${monthsFound.length} months`);
  console.log(`[DEALER_PERFORMANCE] Months: ${monthsFound.join(', ')}`);

  return {
    totalRows: rowsRead,
    recordsInserted,
    validRows: rowsRead,
    invalidRows: 0,
    monthsFound,
    warnings,
    errors
  };
}
