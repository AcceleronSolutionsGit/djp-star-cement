/**
 * PJP Classification Engine (Canonical)
 * 
 * Implements the definitive classification decision tree:
 * 
 *                    Dealer Record
 *                         │
 *              ┌──────────┴──────────┐
 *              │                     │
 *        Prospective?              Dealer
 *              │                     │
 *             YES                    │
 *              ↓                     │
 *        PROSPECTIVE                 │
 *                                    ↓
 *                              Current Sales = 0?
 *                              /              \
 *                            YES               NO
 *                             │                 │
 *                    PM=0 AND 6M=0?            │
 *                       /       \               │
 *                     YES       NO              │
 *                      ↓         ↓              │
 *                    CHURN   ZERO LIFTER         │
 *                                                ↓
 *                                          Compare CM vs PM
 *                                           /      |         \
 *                                          >       =          <
 *                                          ↓       ↓           ↓
 *                                      GROWING  NEED TO GROW   DE-GROWING    
 * 
 * Complete rules:
 * 1. Prospective: CustType = "Prospective" (or dealer_type = "PROSPECTIVE") -> Prospective
 * 2. Churn: CM = 0 AND PM = 0 AND 6M = 0 -> Churn
 * 3. Zero Lifter: CM = 0 AND (PM > 0 OR 6M > 0) -> Zero Lifter
 * 4. Growing: CM > PM -> Growing
 * 5. Stable: CM = PM AND CM > 0 -> Stable
 * 6. Declining: CM < PM AND CM > 0 -> Declining
 */

export function classifyDealer({
  dealerType,
  doa,
  reportMonth,
  currentSales,
  previousMonthSales,
  sameMonthLastYearSales,
  sixMonthAverage,
  needToGrow,
  status,
  custType
}) {
  const cm = Number(currentSales) || 0;
  const pm = Number(previousMonthSales) || 0;
  const avg6m = Number(sixMonthAverage) || 0;
  const type = String(dealerType || custType || '').toUpperCase();
  const stat = String(status || '').toUpperCase();

  // 1. Prospective: if record comes from Prospects file or dealerType/custType is Prospective
  if (type === 'PROSPECTIVE' || type === 'PROSPECT' || stat === 'PROSPECTIVE') {
    return { finalCategory: 'Prospective', reason: 'Prospective dealer' };
  }

  // Explicit Churn status
  if (stat === 'CHURN' || stat === 'INACTIVE') {
    return { finalCategory: 'Churn', reason: 'Dealer status is Churn/Inactive' };
  }

  // 2. Zero current sales check
  if (cm === 0) {
    // Churn: CM = 0 AND PM = 0 AND 6M = 0
    if (pm === 0 && avg6m === 0) {
      return { finalCategory: 'Churn', reason: `Current (${cm}) = 0, Previous (${pm}) = 0, 6M Avg (${avg6m}) = 0` };
    }
    // Zero Lifter: CM = 0 AND (PM > 0 OR 6M > 0)
    return { finalCategory: 'Zero Lifter', reason: `Current = 0, but historical activity exists (PM=${pm}, 6M=${avg6m})` };
  }

  // 3. Compare CM vs PM
  if (cm > pm) {
    return { finalCategory: 'Growing', reason: `Current (${cm}) > Previous (${pm})` };
  }
  if (cm === pm) {
    return { finalCategory: 'Need to Grow', reason: `Current (${cm}) == Previous (${pm})` };
  }
  return { finalCategory: 'De-growing', reason: `Current (${cm}) < Previous (${pm})` };
}

/**
 * Valid Final Categories (strictly approved 6 categories)
 */
export const VALID_CATEGORIES = [
  'Zero lifter',
  'Zero Lifter',
  'Prospective',
  'De-growing',
  'Growing',
  'Need to Grow',
  'Churn'
];
