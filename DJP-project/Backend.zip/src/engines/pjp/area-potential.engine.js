/**
 * PJP Area Potential Engine
 * 
 * Population-level area calculations:
 * - Area Potential = SUM(potential of all dealers in area)
 * - Area Potential Rank = competition ranking within area by potential
 * - Area Potential Percentile = cumulative Pareto-style percentile
 * - Need to Grow determination
 */

/**
 * Normalize area name for consistent grouping.
 * Trims whitespace and converts to uppercase for comparison.
 * Does NOT merge genuinely different area names.
 * @param {string} area 
 * @returns {string} normalized area key
 */
export function normalizeArea(area) {
  if (!area || typeof area !== 'string') return '__UNKNOWN_AREA__';
  return area.trim().toUpperCase();
}

/**
 * Calculate Area Potential, Area Potential Rank, and Area Potential Percentile
 * for all dealers.
 * 
 * @param {Array<Object>} dealers - array of dealer objects with { dealerCode, area, potential }
 * @returns {Map<string, Object>} dealerCode -> { areaPotential, areaPotentialRank, areaPotentialPercentile }
 */
export function calculateAreaPotentialMetrics(dealers) {
  const result = new Map();

  // Group dealers by normalized area
  const areaGroups = new Map();
  for (const d of dealers) {
    // Area grouping uses dm_area (Dealer Mapping authoritative Area)
    // d.area is always set to dm_area by the PJP engine before calling this function
    const areaKey = normalizeArea(d.area || d.dm_area);
    if (!areaGroups.has(areaKey)) areaGroups.set(areaKey, []);
    areaGroups.get(areaKey).push(d);
  }

  for (const [areaKey, group] of areaGroups.entries()) {
    // Area Potential = sum of all dealer SBG potential in area
    // d.potential is set to d.sbg_potential by the PJP engine
    // Dealers with NULL sbg_potential contribute 0 to area potential sum
    // (NULL = SBG not found; not the same as zero potential)
    const areaPotential = group.reduce((sum, d) => sum + (d.potential ?? 0), 0);

    // Area Potential Rank: COUNTIFS(Area = current, Potential > current) + 1
    // Higher potential = rank 1 (best)
    for (const d of group) {
      const higherCount = group.filter(x => (x.potential || 0) > (d.potential || 0)).length;
      const areaPotentialRank = higherCount + 1;

      // Area Potential Percentile (cumulative Pareto-style):
      // SUM(Potential for dealers whose rank >= current rank) / Area Potential
      // rank >= current rank means all dealers with equal or lower potential
      // (i.e., current dealer + all dealers ranked after it)
      const sumForRankGte = group
        .filter(x => {
          const xRank = group.filter(y => (y.potential || 0) > (x.potential || 0)).length + 1;
          return xRank >= areaPotentialRank;
        })
        .reduce((sum, x) => sum + (x.potential || 0), 0);

      const areaPotentialPercentile = areaPotential > 0 ? sumForRankGte / areaPotential : 0;

      result.set(d.dealerCode, {
        areaPotential,
        areaPotentialRank,
        areaPotentialPercentile
      });
    }
  }

  return result;
}

/**
 * Determine Need to Grow for a dealer.
 * 
 * Need to Grow = YES if:
 *   Area Potential Percentile > 60% (0.60)
 *   AND Counter Share < 20% (0.20)
 *   AND dealer is NOT New (DOA != New / not Prospective)
 * 
 * @param {number} areaPotentialPercentile - 0 to 1
 * @param {number} counterShare - 0 to 1
 * @param {boolean} isNew - whether dealer is new/prospective
 * @param {Object} thresholds - { ntgMinPercentile: 0.60, ntgMaxShare: 0.20 }
 * @returns {boolean}
 */
export function determineNeedToGrow(areaPotentialPercentile, counterShare, isNew, thresholds = {}) {
  const minPercentile = thresholds.ntgMinPercentile ?? 0.60;
  const maxShare = thresholds.ntgMaxShare ?? 0.20;

  if (isNew) return false;

  // Safely handle nulls
  const percentile = areaPotentialPercentile ?? 0;
  const share = counterShare ?? 0;

  return percentile > minPercentile && share < maxShare;
}
