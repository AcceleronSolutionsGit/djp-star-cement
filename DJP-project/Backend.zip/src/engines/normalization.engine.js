/**
 * Data Normalization Engine
 * 
 * Provides a single source of truth for normalizing dealer names, areas, blocks,
 * and identifiers to ensure consistent matching across all importers.
 */

/**
 * Normalizes a general string (e.g., Dealer Name, Area, Block).
 * - Trims whitespace
 * - Collapses multiple spaces into single space
 * - Converts to uppercase
 * - Replaces "&" with "AND"
 * - Removes common punctuation that causes mismatch (.,-)
 * - Preserves alphanumerics and spaces
 */
export function normalizeString(str) {
  if (str === null || str === undefined) return null;
  const s = String(str).trim();
  if (s === '') return null;

  return s
    .toUpperCase()
    .replace(/&/g, ' AND ')
    .replace(/[.,-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Normalizes SAP/SFA/Customer Codes.
 * - Trims whitespace
 * - Ensures it's a string, not a float (Excel scientific notation edge cases)
 * - Converts to uppercase
 */
export function normalizeCode(code) {
  if (code === null || code === undefined) return null;
  const s = String(code).trim();
  if (s === '' || s === '-') return null;

  // If it's a number, make sure there's no decimal ".0"
  if (!isNaN(s) && s.includes('.')) {
    return s.split('.')[0];
  }

  return s.toUpperCase();
}

/**
 * Normalizes dealer/customer names.
 */
export function normalizeName(name) {
  return normalizeString(name);
}

/**
 * Normalizes branch names.
 */
export function normalizeBranch(branch) {
  return normalizeString(branch);
}

/**
 * Normalizes region/zone names.
 */
export function normalizeRegion(region) {
  if (region === null || region === undefined) return null;
  const s = String(region).trim();
  if (s === '' || s === '-') return null;
  return s.toUpperCase().replace(/\s+/g, ' ').trim();
}
