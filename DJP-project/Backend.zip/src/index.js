import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import apiRoutes from './routes/api.routes.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static admin panel UI
const adminPath = path.resolve(__dirname, '../admin-panel');
app.use(express.static(adminPath));
app.use('/admin', express.static(adminPath));

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ status: 'UP', message: 'Star Cement PJP / DJP Engine API Platform running.' });
});

// API Routes
app.use('/api', apiRoutes);

app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`Star Cement PJP / DJP Engine Server running on port ${PORT}`);
  console.log(`Admin Panel UI: http://localhost:${PORT}/`);
  console.log(`Health check:    http://localhost:${PORT}/health`);
  console.log(`====================================================`);
});
