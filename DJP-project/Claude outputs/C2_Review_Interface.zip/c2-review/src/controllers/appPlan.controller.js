/**
 * App Plan Controller — ID-scoped endpoints for the field app
 *
 * Every route carries the employee's code in the path. There are no tokens and
 * no session: the app tells us who it is, and each handler checks that the
 * person named in the path actually owns (or approves) the plan being touched.
 *
 * Workflow this implements
 * ------------------------
 *   generation  →  DRAFT
 *   agent edits the DRAFT, then submits      →  SUBMITTED
 *   L1 approves                              →  APPROVED   (end)
 *   L1 sends back for rectification          →  RECTIFY    (allowed ONCE)
 *   agent edits and re-submits               →  SUBMITTED
 *   L1 must now approve — a second RECTIFY is refused
 *
 * Only L1 is involved. There is no second approval level.
 */

import { dbAll, dbGet, dbRun } from '../config/database.js';
import {
  canEdit,
  canApprove,
  stampPlanRouting,
  resolveEmployeeRole,
  MAX_RECTIFICATIONS
} from '../services/planRouting.service.js';

const HARD_DAILY_CAP = 8;

// ─────────────────────────────────────────────────────────────────────────────
// helpers
// ─────────────────────────────────────────────────────────────────────────────

const norm = v => String(v ?? '').trim();
const same = (a, b) => norm(a).toUpperCase() === norm(b).toUpperCase();

async function loadCycleWindow() {
  const rows = await dbAll(
    `SELECT rule_key, rule_value FROM business_rules
     WHERE rule_key IN ('c1_start_day','c1_end_day','c2_start_day','c2_end_day',
                        'daily_visit_capacity','daily_visit_capacity_asm','daily_visit_capacity_rsm')`
  );
  const r = Object.fromEntries(rows.map(x => [x.rule_key, x.rule_value]));
  return {
    C1: { start: parseInt(r.c1_start_day || '1', 10),  end: parseInt(r.c1_end_day || '15', 10) },
    C2: { start: parseInt(r.c2_start_day || '16', 10), end: parseInt(r.c2_end_day || '31', 10) },
    capacity: {
      SO:  parseInt(r.daily_visit_capacity      || '8', 10),
      ASM: parseInt(r.daily_visit_capacity_asm  || '5', 10),
      RSM: parseInt(r.daily_visit_capacity_rsm  || '3', 10),
      ZH:  HARD_DAILY_CAP
    }
  };
}

function dayOf(dateStr) {
  return parseInt(String(dateStr).slice(8, 10), 10);
}

function monthOf(dateStr) {
  return String(dateStr).slice(0, 7);
}

/**
 * What the app is allowed to render as a button, derived from state alone so
 * the client never has to encode the rules itself.
 */
function actionsFor(plan, viewerIsOwner) {
  const editable = ['DRAFT', 'RECTIFY'].includes(plan.status);
  const rectifiedAlready = (plan.rectification_count || 0) >= MAX_RECTIFICATIONS;
  return {
    can_edit:    viewerIsOwner && editable,
    can_submit:  viewerIsOwner && editable,
    can_approve: !viewerIsOwner && plan.status === 'SUBMITTED',
    can_rectify: !viewerIsOwner && plan.status === 'SUBMITTED' && !rectifiedAlready,
    rectify_blocked_reason: rectifiedAlready
      ? 'This plan has already been sent back once. The only remaining action is Approve.'
      : null
  };
}

async function planSummaryRows(where, params) {
  return dbAll(
    `SELECT
       sp.*,
       (SELECT COUNT(*)                    FROM sales_plan_details d WHERE d.plan_id = sp.id) AS total_visits,
       (SELECT COUNT(DISTINCT d.dealer_sap_code) FROM sales_plan_details d WHERE d.plan_id = sp.id) AS total_dealers,
       (SELECT COUNT(DISTINCT d.visit_date)      FROM sales_plan_details d WHERE d.plan_id = sp.id) AS total_days,
       (SELECT MIN(d.visit_date)           FROM sales_plan_details d WHERE d.plan_id = sp.id) AS first_visit_date,
       (SELECT MAX(d.visit_date)           FROM sales_plan_details d WHERE d.plan_id = sp.id) AS last_visit_date
     FROM sales_plans sp
     WHERE ${where}
     ORDER BY sp.period_month DESC, sp.cycle_code ASC, sp.id DESC`,
    params
  );
}

function shapeSummary(p, viewerIsOwner) {
  return {
    plan_id: p.id,
    period_month: p.period_month,
    cycle_code: p.cycle_code,
    status: p.status,
    employee: { emp_code: p.emp_code, emp_name: p.emp_name, role: p.emp_role || 'SO' },
    approver: {
      emp_code: p.l1_approver_emp_code,
      name: p.l1_approver_name,
      role: p.l1_approver_role || p.required_approver_role
    },
    counts: {
      visits: Number(p.total_visits || 0),
      dealers: Number(p.total_dealers || 0),
      working_days: Number(p.total_days || 0)
    },
    date_range: { from: p.first_visit_date, to: p.last_visit_date },
    rectification: {
      count: Number(p.rectification_count || 0),
      remaining: Math.max(0, MAX_RECTIFICATIONS - Number(p.rectification_count || 0)),
      requested_by: p.rectify_requested_by,
      requested_at: p.rectify_requested_at,
      remarks: p.rectify_remarks
    },
    timestamps: {
      created_at: p.created_at,
      submitted_at: p.submitted_at,
      resubmitted_at: p.resubmitted_at,
      approved_at: p.approved_at,
      last_edited_at: p.last_edited_at
    },
    actions: actionsFor(p, viewerIsOwner)
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// AGENT — list view
// GET /api/app/officers/:empCode/plans?month=YYYY-MM&cycle=C1&status=DRAFT
// ─────────────────────────────────────────────────────────────────────────────
export async function listMyPlans(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    if (!empCode) return res.status(400).json({ error: 'empCode is required in the path.' });

    const { month, cycle, status } = req.query;
    let where = 'sp.emp_code = ?';
    const params = [empCode];
    if (month)  { where += ' AND sp.period_month = ?'; params.push(month); }
    if (cycle)  { where += ' AND sp.cycle_code = ?';   params.push(String(cycle).toUpperCase()); }
    if (status) { where += ' AND sp.status = ?';       params.push(String(status).toUpperCase()); }

    const rows = await planSummaryRows(where, params);
    res.json({
      emp_code: empCode,
      emp_name: rows[0]?.emp_name || null,
      role: rows[0]?.emp_role || await resolveEmployeeRole(empCode),
      count: rows.length,
      plans: rows.map(p => shapeSummary(p, true))
    });
  } catch (err) {
    console.error('[listMyPlans]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// AGENT — home screen counters
// GET /api/app/officers/:empCode/summary?month=YYYY-MM
// ─────────────────────────────────────────────────────────────────────────────
export async function getMySummary(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const { month } = req.query;

    const params = [empCode];
    let where = 'emp_code = ?';
    if (month) { where += ' AND period_month = ?'; params.push(month); }

    const byStatus = await dbAll(
      `SELECT status, COUNT(*) AS n FROM sales_plans WHERE ${where} GROUP BY status`, params
    );
    const role = await resolveEmployeeRole(empCode);

    const inboxParams = [empCode];
    let inboxWhere = "l1_approver_emp_code = ? AND status = 'SUBMITTED'";
    if (month) { inboxWhere += ' AND period_month = ?'; inboxParams.push(month); }
    const inbox = await dbGet(`SELECT COUNT(*) AS n FROM sales_plans WHERE ${inboxWhere}`, inboxParams);

    res.json({
      emp_code: empCode,
      role,
      month: month || 'ALL',
      my_plans: Object.fromEntries(byStatus.map(r => [r.status, Number(r.n)])),
      awaiting_my_approval: Number(inbox?.n || 0),
      action_required: Number(
        (byStatus.find(r => r.status === 'DRAFT')?.n || 0)
      ) + Number(
        (byStatus.find(r => r.status === 'RECTIFY')?.n || 0)
      )
    });
  } catch (err) {
    console.error('[getMySummary]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// detail view (shared by agent and approver)
// GET /api/app/officers/:empCode/plans/:planId
// GET /api/app/approvers/:empCode/plans/:planId
// ─────────────────────────────────────────────────────────────────────────────
async function buildDetail(plan, viewerIsOwner) {
  const visits = await dbAll(
    `SELECT
       d.id            AS detail_id,
       d.visit_date,
       d.sequence,
       d.dealer_id,
       d.dealer_sap_code,
       d.dealer_name,
       d.dealer_type,
       d.purpose_of_visit,
       COALESCE(d.visit_status, 'ACTIVE') AS visit_status,
       COALESCE(d.source, 'AUTO')         AS source,
       dvt.dealer_status AS final_category,
       dvt.category      AS grade,
       dvt.priority      AS priority_score,
       dvt.area,
       dvt.zone,
       md.block,
       md.sfa_code
     FROM sales_plan_details d
     LEFT JOIN dealer_visit_targets dvt
            ON dvt.sap_code = d.dealer_sap_code
           AND dvt.period_month = ?
           AND dvt.cycle_code   = ?
     LEFT JOIN master_dealers md ON md.id = d.dealer_id
     WHERE d.plan_id = ?
     ORDER BY d.visit_date ASC, d.sequence ASC`,
    [plan.period_month, plan.cycle_code, plan.id]
  );

  const byDay = new Map();
  for (const v of visits) {
    const k = String(v.visit_date).slice(0, 10);
    if (!byDay.has(k)) byDay.set(k, []);
    byDay.get(k).push(v);
  }

  const history = await dbAll(
    `SELECT action_by, action_type, approver_role, remarks, created_at
     FROM plan_approvals WHERE plan_id = ? ORDER BY id ASC`,
    [plan.id]
  ).catch(() => []);

  const categoryMix = visits.reduce((acc, v) => {
    const k = v.final_category || 'Unclassified';
    acc[k] = (acc[k] || 0) + 1;
    return acc;
  }, {});

  return {
    ...shapeSummary({ ...plan,
      total_visits: visits.length,
      total_dealers: new Set(visits.map(v => v.dealer_sap_code)).size,
      total_days: byDay.size,
      first_visit_date: visits[0]?.visit_date || null,
      last_visit_date: visits[visits.length - 1]?.visit_date || null
    }, viewerIsOwner),
    category_mix: categoryMix,
    days: [...byDay.entries()].map(([date, list]) => ({
      visit_date: date,
      visit_count: list.length,
      visits: list.map(v => ({
        detail_id: v.detail_id,
        sequence: v.sequence,
        dealer: {
          dealer_id: v.dealer_id,
          sap_code: v.dealer_sap_code,
          sfa_code: v.sfa_code,
          name: v.dealer_name,
          type: v.dealer_type,
          area: v.area,
          zone: v.zone,
          block: v.block
        },
        final_category: v.final_category,
        grade: v.grade,
        priority_score: v.priority_score,
        purpose_of_visit: v.purpose_of_visit,
        visit_status: v.visit_status,
        source: v.source
      }))
    })),
    history
  };
}

export async function getMyPlanDetail(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const plan = await dbGet('SELECT * FROM sales_plans WHERE id = ?', [req.params.planId]);
    if (!plan) return res.status(404).json({ error: 'Plan not found.' });
    if (!same(plan.emp_code, empCode)) {
      return res.status(403).json({ error: `Plan ${plan.id} does not belong to ${empCode}.` });
    }
    res.json({ plan: await buildDetail(plan, true) });
  } catch (err) {
    console.error('[getMyPlanDetail]', err);
    res.status(500).json({ error: err.message });
  }
}

export async function getPlanForApproval(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const plan = await dbGet('SELECT * FROM sales_plans WHERE id = ?', [req.params.planId]);
    if (!plan) return res.status(404).json({ error: 'Plan not found.' });

    const check = await canApprove(plan, empCode);
    if (!check.ok) return res.status(403).json({ error: check.reason });

    res.json({ plan: await buildDetail(plan, false), approving_as: check.approverRole, via: check.via });
  } catch (err) {
    console.error('[getPlanForApproval]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// AGENT — edit
// ─────────────────────────────────────────────────────────────────────────────

async function guardEditable(planId, empCode) {
  const plan = await dbGet('SELECT * FROM sales_plans WHERE id = ?', [planId]);
  const verdict = canEdit(plan, empCode);
  return { plan, verdict };
}

async function touch(planId, empCode) {
  await dbRun(
    'UPDATE sales_plans SET last_edited_by = ?, last_edited_at = CURRENT_TIMESTAMP WHERE id = ?',
    [empCode, planId]
  );
}

/**
 * Validate a proposed visit date against the plan's own cycle window.
 * A C1 plan cannot hold a day-20 visit, and neither cycle can cross months.
 */
async function validateVisitDate(plan, visitDate) {
  const cycles = await loadCycleWindow();
  const win = cycles[plan.cycle_code] || cycles.C1;

  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(visitDate))) {
    return `visitDate must be YYYY-MM-DD, received '${visitDate}'.`;
  }
  if (monthOf(visitDate) !== plan.period_month) {
    return `Visit date ${visitDate} is outside the plan month ${plan.period_month}.`;
  }
  const d = dayOf(visitDate);
  if (d < win.start || d > win.end) {
    return `Visit date ${visitDate} (day ${d}) is outside cycle ${plan.cycle_code} (days ${win.start}-${win.end}).`;
  }
  return null;
}

/**
 * Daily capacity + one-visit-per-dealer-per-day, the same two rules the
 * generator enforces. Without this an agent could hand-build a day the
 * generator would never have produced.
 */
async function validateDayCapacity(plan, visitDate, dealerSapCode, excludeDetailId = null) {
  const cycles = await loadCycleWindow();
  const cap = Math.min(cycles.capacity[plan.emp_role || 'SO'] ?? HARD_DAILY_CAP, HARD_DAILY_CAP);

  const existing = await dbAll(
    `SELECT id, dealer_sap_code FROM sales_plan_details
     WHERE plan_id = ? AND visit_date = ? ${excludeDetailId ? 'AND id != ?' : ''}`,
    excludeDetailId ? [plan.id, visitDate, excludeDetailId] : [plan.id, visitDate]
  );

  if (existing.length >= cap) {
    return `${visitDate} already has ${existing.length} visits — the daily cap for a ${plan.emp_role || 'SO'} is ${cap}.`;
  }
  if (existing.some(e => same(e.dealer_sap_code, dealerSapCode))) {
    return `${dealerSapCode} is already scheduled on ${visitDate}. A dealer can only be visited once a day.`;
  }
  return null;
}

/**
 * POST /api/app/officers/:empCode/plans/:planId/visits
 * Body: { visitDate, dealerSapCode, purposeOfVisit? }
 */
export async function addVisit(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const { plan, verdict } = await guardEditable(req.params.planId, empCode);
    if (!verdict.ok) return res.status(plan ? 409 : 404).json({ error: verdict.reason });

    const visitDate = norm(req.body.visitDate);
    const dealerSapCode = norm(req.body.dealerSapCode);
    if (!visitDate || !dealerSapCode) {
      return res.status(400).json({ error: 'visitDate and dealerSapCode are required.' });
    }

    const dateErr = await validateVisitDate(plan, visitDate);
    if (dateErr) return res.status(400).json({ error: dateErr });

    // The dealer must actually be one of this employee's targets for the period.
    const roleCol = { SO: 'so_emp_code', ASM: 'asm_code', RSM: 'rsm_code', ZH: 'zh_code' }[plan.emp_role || 'SO'];
    const target = await dbGet(
      `SELECT dvt.*, md.id AS md_id, md.dealer_type
       FROM dealer_visit_targets dvt
       LEFT JOIN master_dealers md ON md.sap_code = dvt.sap_code
       WHERE dvt.sap_code = ? AND dvt.period_month = ? AND dvt.cycle_code = ? AND dvt.${roleCol} = ?
       LIMIT 1`,
      [dealerSapCode, plan.period_month, plan.cycle_code, plan.emp_code]
    );
    if (!target) {
      return res.status(400).json({
        error: `${dealerSapCode} is not one of ${plan.emp_code}'s dealers for ${plan.period_month} ${plan.cycle_code}.`,
        hint: 'Use GET /api/app/officers/:empCode/dealers to list the dealers this plan may draw from.'
      });
    }

    const capErr = await validateDayCapacity(plan, visitDate, dealerSapCode);
    if (capErr) return res.status(409).json({ error: capErr });

    const seqRow = await dbGet(
      'SELECT COALESCE(MAX(sequence), 0) + 1 AS next FROM sales_plan_details WHERE plan_id = ? AND visit_date = ?',
      [plan.id, visitDate]
    );

    const result = await dbRun(
      `INSERT INTO sales_plan_details
       (plan_id, visit_date, dealer_id, dealer_sap_code, dealer_name, dealer_type, purpose_of_visit, sequence, visit_status, source, added_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', 'AGENT', ?)`,
      [
        plan.id, visitDate, target.dealer_id || target.md_id || null, dealerSapCode,
        target.dealer_name, target.dealer_type || 'DEALER',
        norm(req.body.purposeOfVisit) || `Agent added (${target.category || '-'} - ${target.dealer_status || 'Routine'})`,
        seqRow?.next || 1, empCode
      ]
    );
    await touch(plan.id, empCode);

    res.json({
      success: true,
      message: `${target.dealer_name} added to ${visitDate}.`,
      detail_id: result.insertId || result.lastID,
      plan_id: plan.id
    });
  } catch (err) {
    console.error('[addVisit]', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * DELETE /api/app/officers/:empCode/plans/:planId/visits/:detailId
 */
export async function removeVisit(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const { plan, verdict } = await guardEditable(req.params.planId, empCode);
    if (!verdict.ok) return res.status(plan ? 409 : 404).json({ error: verdict.reason });

    const detail = await dbGet(
      'SELECT * FROM sales_plan_details WHERE id = ? AND plan_id = ?',
      [req.params.detailId, plan.id]
    );
    if (!detail) return res.status(404).json({ error: 'Visit not found on this plan.' });

    await dbRun('DELETE FROM sales_plan_details WHERE id = ?', [req.params.detailId]);
    await touch(plan.id, empCode);

    res.json({
      success: true,
      message: `${detail.dealer_name} removed from ${String(detail.visit_date).slice(0, 10)}.`,
      plan_id: plan.id
    });
  } catch (err) {
    console.error('[removeVisit]', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * PUT /api/app/officers/:empCode/plans/:planId/visits/:detailId
 * Body: { visitDate?, sequence?, purposeOfVisit? }
 */
export async function moveVisit(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const { plan, verdict } = await guardEditable(req.params.planId, empCode);
    if (!verdict.ok) return res.status(plan ? 409 : 404).json({ error: verdict.reason });

    const detail = await dbGet(
      'SELECT * FROM sales_plan_details WHERE id = ? AND plan_id = ?',
      [req.params.detailId, plan.id]
    );
    if (!detail) return res.status(404).json({ error: 'Visit not found on this plan.' });

    const newDate = norm(req.body.visitDate) || String(detail.visit_date).slice(0, 10);
    const dateErr = await validateVisitDate(plan, newDate);
    if (dateErr) return res.status(400).json({ error: dateErr });

    if (newDate !== String(detail.visit_date).slice(0, 10)) {
      const capErr = await validateDayCapacity(plan, newDate, detail.dealer_sap_code, detail.id);
      if (capErr) return res.status(409).json({ error: capErr });
    }

    const seq = req.body.sequence != null
      ? parseInt(req.body.sequence, 10)
      : (await dbGet(
          'SELECT COALESCE(MAX(sequence), 0) + 1 AS next FROM sales_plan_details WHERE plan_id = ? AND visit_date = ? AND id != ?',
          [plan.id, newDate, detail.id]
        ))?.next || 1;

    await dbRun(
      `UPDATE sales_plan_details
       SET visit_date = ?, sequence = ?, purpose_of_visit = COALESCE(?, purpose_of_visit)
       WHERE id = ?`,
      [newDate, seq, norm(req.body.purposeOfVisit) || null, detail.id]
    );
    await touch(plan.id, empCode);

    res.json({
      success: true,
      message: `${detail.dealer_name} moved to ${newDate}.`,
      plan_id: plan.id,
      detail_id: Number(req.params.detailId)
    });
  } catch (err) {
    console.error('[moveVisit]', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * GET /api/app/officers/:empCode/dealers?month=&cycle=
 * The dealer pool this employee may add from, with the ones already on the plan flagged.
 */
export async function getMyDealers(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const month = norm(req.query.month);
    const cycle = norm(req.query.cycle).toUpperCase() || 'C1';
    if (!month) return res.status(400).json({ error: 'month (YYYY-MM) is required.' });

    const role = await resolveEmployeeRole(empCode);
    const roleCol  = { SO: 'so_emp_code', ASM: 'asm_code', RSM: 'rsm_code', ZH: 'zh_code' }[role];
    const visitCol = { SO: 'so_visits',   ASM: 'asm_visits', RSM: 'rsm_visits', ZH: 'zh_visits' }[role];

    const dealers = await dbAll(
      `SELECT dvt.sap_code, dvt.sfa_code, dvt.dealer_name, dvt.area, dvt.zone,
              dvt.dealer_status AS final_category, dvt.category AS grade,
              dvt.priority AS priority_score, dvt.${visitCol} AS required_visits,
              md.block,
              (SELECT COUNT(*) FROM sales_plan_details d
                 JOIN sales_plans p ON p.id = d.plan_id
                WHERE p.emp_code = ? AND p.period_month = ? AND p.cycle_code = ?
                  AND d.dealer_sap_code = dvt.sap_code) AS already_planned
       FROM dealer_visit_targets dvt
       LEFT JOIN master_dealers md ON md.sap_code = dvt.sap_code
       WHERE dvt.${roleCol} = ? AND dvt.period_month = ? AND dvt.cycle_code = ? AND dvt.${visitCol} > 0
       ORDER BY md.block ASC, dvt.priority DESC, dvt.dealer_name ASC`,
      [empCode, month, cycle, empCode, month, cycle]
    );

    res.json({ emp_code: empCode, role, month, cycle, count: dealers.length, dealers });
  } catch (err) {
    console.error('[getMyDealers]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// AGENT — submit
// POST /api/app/officers/:empCode/plans/:planId/submit
// ─────────────────────────────────────────────────────────────────────────────
export async function submitMyPlan(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const plan = await dbGet('SELECT * FROM sales_plans WHERE id = ?', [req.params.planId]);
    if (!plan) return res.status(404).json({ error: 'Plan not found.' });

    const verdict = canEdit(plan, empCode);
    if (!verdict.ok) return res.status(409).json({ error: verdict.reason });

    const count = await dbGet('SELECT COUNT(*) AS n FROM sales_plan_details WHERE plan_id = ?', [plan.id]);
    if (!count || Number(count.n) === 0) {
      return res.status(400).json({ error: 'Cannot submit an empty plan — add at least one visit first.' });
    }

    // Re-resolve routing at submit time; the hierarchy may have changed since generation.
    const routing = await stampPlanRouting(plan.id, { roleHint: plan.emp_role });
    if (!routing.l1ApproverEmpCode && routing.l1ApproverRole !== 'ADMIN') {
      return res.status(409).json({
        error: `No L1 approver could be resolved for ${empCode} (${routing.empRole}). The plan cannot be submitted until the hierarchy is corrected.`,
        routing
      });
    }

    const isResubmit = plan.status === 'RECTIFY';
    await dbRun(
      `UPDATE sales_plans
       SET status = 'SUBMITTED',
           submitted_at   = COALESCE(submitted_at, CURRENT_TIMESTAMP),
           resubmitted_at = ${isResubmit ? 'CURRENT_TIMESTAMP' : 'resubmitted_at'}
       WHERE id = ?`,
      [plan.id]
    );
    await dbRun(
      'INSERT INTO plan_approvals (plan_id, action_by, action_type, remarks) VALUES (?, ?, ?, ?)',
      [plan.id, empCode, isResubmit ? 'RESUBMITTED' : 'SUBMITTED', norm(req.body?.remarks) || null]
    ).catch(e => console.warn('[submitMyPlan] audit log skipped:', e.message));

    res.json({
      success: true,
      message: isResubmit
        ? `Plan ${plan.id} re-submitted after rectification. ${routing.l1ApproverName || routing.l1ApproverRole} must now approve it — it cannot be sent back again.`
        : `Plan ${plan.id} submitted to ${routing.l1ApproverName || routing.l1ApproverRole} for approval.`,
      plan_id: plan.id,
      status: 'SUBMITTED',
      is_resubmission: isResubmit,
      visits_submitted: Number(count.n),
      approver: {
        emp_code: routing.l1ApproverEmpCode,
        name: routing.l1ApproverName,
        role: routing.l1ApproverRole
      },
      rectification_remaining: Math.max(0, MAX_RECTIFICATIONS - Number(plan.rectification_count || 0))
    });
  } catch (err) {
    console.error('[submitMyPlan]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// L1 — inbox
// GET /api/app/approvers/:empCode/inbox?month=&status=
// ─────────────────────────────────────────────────────────────────────────────
export async function getApprovalInbox(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const month = norm(req.query.month);
    const status = norm(req.query.status).toUpperCase() || 'SUBMITTED';

    const role = await resolveEmployeeRole(empCode);
    const isAdmin = role === 'ADMIN';

    let where = isAdmin
      ? "(sp.l1_approver_emp_code = ? OR sp.l1_approver_role = 'ADMIN')"
      : 'sp.l1_approver_emp_code = ?';
    const params = [empCode];

    if (status !== 'ALL') { where += ' AND sp.status = ?'; params.push(status); }
    if (month)            { where += ' AND sp.period_month = ?'; params.push(month); }

    const rows = await planSummaryRows(where, params);
    res.json({
      approver: { emp_code: empCode, role },
      filter: { status, month: month || 'ALL' },
      count: rows.length,
      plans: rows.map(p => shapeSummary(p, false))
    });
  } catch (err) {
    console.error('[getApprovalInbox]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// L1 — decision
// POST /api/app/approvers/:empCode/plans/:planId/decision
// Body: { action: 'APPROVE' | 'RECTIFY', remarks? }
// ─────────────────────────────────────────────────────────────────────────────
export async function decidePlan(req, res) {
  try {
    const empCode = norm(req.params.empCode);
    const action = norm(req.body.action).toUpperCase();
    const remarks = norm(req.body.remarks);

    if (!['APPROVE', 'APPROVED', 'RECTIFY'].includes(action)) {
      return res.status(400).json({ error: "action must be 'APPROVE' or 'RECTIFY'." });
    }
    const isApprove = action !== 'RECTIFY';

    const plan = await dbGet('SELECT * FROM sales_plans WHERE id = ?', [req.params.planId]);
    if (!plan) return res.status(404).json({ error: 'Plan not found.' });

    if (plan.status !== 'SUBMITTED') {
      return res.status(409).json({
        error: `Only a SUBMITTED plan can be acted on. Plan ${plan.id} is ${plan.status}.`
      });
    }

    const check = await canApprove(plan, empCode);
    if (!check.ok) return res.status(403).json({ error: check.reason });

    // ── rectify-once ─────────────────────────────────────────────────────────
    if (!isApprove) {
      const used = Number(plan.rectification_count || 0);
      if (used >= MAX_RECTIFICATIONS) {
        return res.status(409).json({
          error: `Plan ${plan.id} has already been sent back for rectification once. The only remaining action is Approve.`,
          rectification_count: used,
          allowed_actions: ['APPROVE']
        });
      }
      if (!remarks) {
        return res.status(400).json({ error: 'remarks are required when sending a plan back — the agent needs to know what to fix.' });
      }

      await dbRun(
        `UPDATE sales_plans
         SET status = 'RECTIFY',
             rectification_count  = rectification_count + 1,
             rectify_requested_by = ?, rectify_requested_at = CURRENT_TIMESTAMP,
             rectify_remarks      = ?
         WHERE id = ?`,
        [empCode, remarks, plan.id]
      );
      await dbRun(
        'INSERT INTO plan_approvals (plan_id, action_by, action_type, remarks, approver_role) VALUES (?, ?, ?, ?, ?)',
        [plan.id, empCode, 'RECTIFY', remarks, check.approverRole || null]
      ).catch(e => console.warn('[decidePlan] audit log skipped:', e.message));

      return res.json({
        success: true,
        message: `Plan ${plan.id} sent back to ${plan.emp_name} for rectification. This was the only send-back available — the next submission must be approved.`,
        plan_id: plan.id,
        status: 'RECTIFY',
        rectification_count: used + 1,
        rectification_remaining: 0,
        remarks
      });
    }

    // ── approve ──────────────────────────────────────────────────────────────
    await dbRun(
      `UPDATE sales_plans
       SET status = 'APPROVED', approved_by = ?, approver_emp_code = ?,
           approved_at = CURRENT_TIMESTAMP, remarks = COALESCE(NULLIF(?, ''), remarks)
       WHERE id = ?`,
      [empCode, empCode, remarks, plan.id]
    );
    await dbRun(
      'INSERT INTO plan_approvals (plan_id, action_by, action_type, remarks, approver_role) VALUES (?, ?, ?, ?, ?)',
      [plan.id, empCode, 'APPROVED', remarks || null, check.approverRole || null]
    ).catch(e => console.warn('[decidePlan] audit log skipped:', e.message));

    res.json({
      success: true,
      message: `Plan ${plan.id} approved by ${empCode}.`,
      plan_id: plan.id,
      status: 'APPROVED',
      approved_by: empCode,
      approver_role: check.approverRole,
      via: check.via
    });
  } catch (err) {
    console.error('[decidePlan]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN — every officer's plan in one list
// GET /api/app/admin/plans?month=&cycle=&status=&role=&search=&limit=&offset=
// ─────────────────────────────────────────────────────────────────────────────
export async function listAllPlans(req, res) {
  try {
    const { month, cycle, status, role, search } = req.query;
    const limit  = Math.min(parseInt(req.query.limit || '500', 10), 2000);
    const offset = parseInt(req.query.offset || '0', 10);

    // Every filter EXCEPT cycle is applied in SQL. Cycle is applied afterwards in JS
    // so the C1 / C2 switch can carry live counts that stay correct while one cycle
    // is selected — otherwise selecting C1 would zero the C2 count.
    let where = '1=1';
    const params = [];
    if (month)  { where += ' AND sp.period_month = ?'; params.push(month); }
    if (status && status !== 'ALL') { where += ' AND sp.status = ?';     params.push(String(status).toUpperCase()); }
    if (role   && role   !== 'ALL') { where += ' AND sp.emp_role = ?';   params.push(String(role).toUpperCase()); }
    if (search) {
      where += ' AND (sp.emp_name LIKE ? OR sp.emp_code LIKE ? OR sp.l1_approver_name LIKE ?)';
      const q = `%${search}%`;
      params.push(q, q, q);
    }

    const allRows = await planSummaryRows(where, params);

    const cycleCounts = allRows.reduce((acc, p) => {
      acc[p.cycle_code] = (acc[p.cycle_code] || 0) + 1;
      acc.ALL += 1;
      return acc;
    }, { ALL: 0, C1: 0, C2: 0 });

    const wantCycle = cycle && cycle !== 'ALL' ? String(cycle).toUpperCase() : null;
    const rows = wantCycle ? allRows.filter(p => p.cycle_code === wantCycle) : allRows;
    const page = rows.slice(offset, offset + limit);

    // Roll-up tiles for the top of the screen
    const totals = rows.reduce((acc, p) => {
      acc.plans += 1;
      acc.visits += Number(p.total_visits || 0);
      acc.by_status[p.status] = (acc.by_status[p.status] || 0) + 1;
      acc.by_role[p.emp_role || 'SO'] = (acc.by_role[p.emp_role || 'SO'] || 0) + 1;
      if (!p.l1_approver_emp_code && p.l1_approver_role !== 'ADMIN') acc.unrouted += 1;
      if (Number(p.total_visits || 0) === 0) acc.empty += 1;
      return acc;
    }, { plans: 0, visits: 0, by_status: {}, by_role: {}, unrouted: 0, empty: 0 });

    res.json({
      filter: { month: month || 'ALL', cycle: cycle || 'ALL', status: status || 'ALL', role: role || 'ALL' },
      cycleCounts,
      totals,
      count: rows.length,
      returned: page.length,
      plans: page.map(p => shapeSummary(p, false))
    });
  } catch (err) {
    console.error('[listAllPlans]', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * GET /api/app/admin/plans/:planId — detail view with no ownership check.
 */
export async function getPlanDetailAdmin(req, res) {
  try {
    const plan = await dbGet('SELECT * FROM sales_plans WHERE id = ?', [req.params.planId]);
    if (!plan) return res.status(404).json({ error: 'Plan not found.' });
    res.json({ plan: await buildDetail(plan, false) });
  } catch (err) {
    console.error('[getPlanDetailAdmin]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN — read-only adherence report
// GET /api/app/admin/adherence?month=YYYY-MM&cycle=C1|C2&asOn=YYYY-MM-DD&productiveOnly=1
//
// Uses the method taken from the client's own workbook: MTD due is the planned
// visit count prorated by how much of the cycle has elapsed at the as-on date,
// adherence is adhered ÷ MTD due, and pending goes negative when someone
// over-visits. Capped and uncapped are both reported because the client keeps both.
//
// Read-only. Nothing is regenerated.
// ─────────────────────────────────────────────────────────────────────────────
export async function getAdherenceReport(req, res) {
  try {
    const month = norm(req.query.month);
    if (!/^\d{4}-\d{2}$/.test(month)) {
      return res.status(400).json({ error: 'month (YYYY-MM) is required.' });
    }
    const cycle = norm(req.query.cycle).toUpperCase();
    const asOn  = norm(req.query.asOn);
    if (asOn && !/^\d{4}-\d{2}-\d{2}$/.test(asOn)) {
      return res.status(400).json({ error: `asOn must be YYYY-MM-DD, received '${asOn}'.` });
    }

    const { analyseAdherence } = await import('../engines/sfa-adherence.engine.js');
    const a = await analyseAdherence({
      periodMonth: month,
      cycleCode: cycle && cycle !== 'ALL' ? cycle : null,
      asOnDate: asOn || null,
      productiveOnly: req.query.productiveOnly === '1' || req.query.productiveOnly === 'true'
    });

    const pct = n => Math.round(n * 1000) / 10;   // one decimal, as a percentage

    res.json({
      period_month: month,
      cycles: a.cycles,
      as_on_date: a.asOnDate,
      cycle_windows: a.windows,
      elapsed_fraction: a.elapsedFraction,
      method: 'MTD due = planned x elapsed fraction of the cycle; adherence = adhered / MTD due, falling back to full planned when MTD due < 1',

      totals: {
        dealers_on_plan: a.totals.dealers,
        dealers_visited: a.totals.dealers_visited,
        dealers_missed:  a.totals.dealers_missed,
        planned_visits:  a.totals.planned,
        mtd_due:         Math.round(a.totals.mtd_planned * 100) / 100,
        adhered:         a.totals.adhered,
        adhered_capped:  a.totals.adhered_capped,
        pending:         Math.round(a.totals.pending * 100) / 100,
        sfa_visits_in_window: a.diagnostics.sfa_visits_in_window
      },

      adherence: {
        capped_pct:   pct(a.totals.adherence_pct_capped),
        raw_pct:      pct(a.totals.adherence_pct),
        coverage_pct: pct(a.totals.coverage_pct),
        over_visited: a.totals.adhered > a.totals.mtd_planned,
        note: 'capped is MIN(actual, planned) per dealer — it never exceeds 100%. raw can, and negative pending means over-visiting.'
      },

      by_cycle: Object.fromEntries(Object.entries(a.byCycle).map(([c, v]) => [c, {
        elapsed_fraction: Math.round(v.elapsed_fraction * 1000) / 1000,
        dealers: v.dealers, planned: v.planned,
        mtd_due: Math.round(v.mtd_planned * 100) / 100,
        adhered: v.adhered, adhered_capped: v.adhered_capped,
        capped_pct: pct(v.adherence_pct_capped), raw_pct: pct(v.adherence_pct),
        pending: Math.round(v.pending * 100) / 100
      }])),

      by_role: Object.fromEntries(Object.entries(a.byRole).map(([r, v]) => [r, {
        dealers: v.dealers, planned: v.planned,
        mtd_due: Math.round(v.mtd_planned * 100) / 100,
        adhered: v.adhered, adhered_capped: v.adhered_capped,
        capped_pct: pct(v.adherence_pct_capped), raw_pct: pct(v.adherence_pct),
        pending: Math.round(v.pending * 100) / 100,
        coverage_pct: pct(v.coverage_pct)
      }])),

      by_employee: a.byEmployee.map(e => ({
        emp_code: e.emp_code, emp_name: e.emp_name, role: e.role, cycles: e.cycles,
        planned_dealers: e.dealers, visited: e.dealers_visited, missed: e.dealers_missed,
        planned_visits: e.planned,
        mtd_due: Math.round(e.mtd_planned * 100) / 100,
        adhered: e.adhered, adhered_capped: e.adhered_capped,
        capped_pct: pct(e.adherence_pct_capped), raw_pct: pct(e.adherence_pct),
        pending: Math.round(e.pending * 100) / 100,
        adherence_pct: pct(e.adherence_pct_capped),   // what the UI bar reads
        missed_dealers: e.missed_dealers.map(d => ({
          sap_code: d.sap_code, name: d.name, planned_date: d.planned_dates?.[0] || null
        }))
      })),

      by_dealer: a.byDealer.map(d => ({
        cycle: d.cycle_code, role: d.role,
        emp_code: d.emp_code, emp_name: d.emp_name,
        sap_code: d.dealer_sap_code, dealer_name: d.dealer_name,
        planned: d.planned,
        mtd_due: Math.round(d.mtd_planned * 100) / 100,
        adhered: d.adhered, adhered_capped: d.adhered_capped, adhered_days: d.adhered_days,
        capped_pct: pct(d.adherence_pct_capped), raw_pct: pct(d.adherence_pct),
        pending: Math.round(d.pending * 100) / 100,
        planned_dates: d.planned_dates, visit_dates: d.visit_dates
      })),

      diagnostics: {
        resolved_via_sfa_code: a.diagnostics.resolved_via_sfa_code,
        resolved_via_sfa_code_note: 'visits logged with the SFA customer code and resolved to the SAP code the plan uses — these used to read as missed',
        unresolved_visits: a.diagnostics.unresolved_visits,
        unresolved_detail: a.diagnostics.unresolved_detail,
        unplanned_visits: a.diagnostics.unplanned_visits,
        unplanned_detail: a.diagnostics.unplanned_detail
      }
    });
  } catch (err) {
    console.error('[getAdherenceReport]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN — C2 regeneration review
//
// GET /api/app/admin/c2-regenerations?month=          list the runs
// GET /api/app/admin/c2-regenerations/:id             one run, with the full diff
//
// Answers the question the plan list cannot: what did the adherence result actually
// change? Regeneration deletes the previous C2, so the comparison is made against the
// snapshot taken either side of the purge rather than against live tables.
// ─────────────────────────────────────────────────────────────────────────────
export async function listC2Regenerations(req, res) {
  try {
    const month = norm(req.query.month);
    const params = [];
    let where = '1=1';
    if (month) { where += ' AND period_month = ?'; params.push(month); }

    let runs;
    try {
      runs = await dbAll(
        `SELECT * FROM c2_regenerations WHERE ${where} ORDER BY started_at DESC LIMIT 50`,
        params
      );
    } catch (e) {
      return res.status(409).json({
        error: 'C2 regeneration history is not set up yet.',
        fix: 'Run: node src/scripts/migrate-c2-review.js, then regenerate C2 once.'
      });
    }

    res.json({
      month: month || 'ALL',
      count: runs.length,
      regenerations: runs.map(r => ({
        id: r.id,
        generation_code: r.generation_code,
        period_month: r.period_month,
        status: r.status,
        started_at: r.started_at,
        completed_at: r.completed_at,
        adherence: {
          as_on: r.adherence_as_on,
          planned: r.adherence_planned,
          adhered: r.adherence_adhered,
          missed: r.adherence_missed,
          pct: r.adherence_pct
        },
        before: { plans: r.plans_before, visits: r.visits_before },
        after:  { plans: r.plans_after,  visits: r.visits_after },
        visit_delta: (r.visits_after || 0) - (r.visits_before || 0),
        first_run: (r.visits_before || 0) === 0
      }))
    });
  } catch (err) {
    console.error('[listC2Regenerations]', err);
    res.status(500).json({ error: err.message });
  }
}

export async function getC2Regeneration(req, res) {
  try {
    const run = await dbGet('SELECT * FROM c2_regenerations WHERE id = ?', [req.params.id])
      .catch(() => null);
    if (!run) return res.status(404).json({ error: 'Regeneration not found.' });

    const lines = await dbAll(
      'SELECT * FROM c2_regeneration_lines WHERE regeneration_id = ? ORDER BY emp_code, visit_date, sequence',
      [run.id]
    );
    const before = lines.filter(l => l.phase === 'BEFORE');
    const after  = lines.filter(l => l.phase === 'AFTER');

    let missedCodes = [];
    try { missedCodes = JSON.parse(run.missed_dealer_codes || '[]'); } catch (e) { /* ignore */ }

    const { diffLines } = await import('../services/c2Snapshot.service.js');
    const { changes, summary } = diffLines(before, after, missedCodes);

    // Group the new plan by officer so the screen can show each schedule in full,
    // with the carried-over dealers marked in place.
    const missedSet = new Set(missedCodes.map(c => norm(c).toUpperCase()));
    const byOfficer = new Map();
    for (const l of after) {
      const k = norm(l.emp_code);
      if (!byOfficer.has(k)) {
        byOfficer.set(k, {
          emp_code: l.emp_code, emp_name: l.emp_name, role: l.emp_role,
          visits: 0, dealers: new Set(), days: new Set(), lines: []
        });
      }
      const o = byOfficer.get(k);
      o.visits += 1;
      o.dealers.add(norm(l.dealer_sap_code));
      o.days.add(String(l.visit_date).slice(0, 10));
      o.lines.push({
        visit_date: String(l.visit_date).slice(0, 10),
        sequence: l.sequence,
        dealer_sap_code: l.dealer_sap_code,
        dealer_name: l.dealer_name,
        carried_over: missedSet.has(norm(l.dealer_sap_code).toUpperCase())
      });
    }

    const changesByOfficer = changes.reduce((acc, c) => {
      const k = norm(c.emp_code);
      (acc[k] = acc[k] || []).push(c);
      return acc;
    }, {});

    res.json({
      regeneration: {
        id: run.id,
        generation_code: run.generation_code,
        period_month: run.period_month,
        status: run.status,
        started_at: run.started_at,
        completed_at: run.completed_at,
        adherence: {
          as_on: run.adherence_as_on,
          planned: run.adherence_planned,
          adhered: run.adherence_adhered,
          missed: run.adherence_missed,
          pct: run.adherence_pct
        },
        before: { plans: run.plans_before, visits: run.visits_before },
        after:  { plans: run.plans_after,  visits: run.visits_after },
        first_run: (run.visits_before || 0) === 0
      },
      summary,
      changes,
      officers: [...byOfficer.values()]
        .map(o => ({
          emp_code: o.emp_code, emp_name: o.emp_name, role: o.role,
          visits: o.visits, dealers: o.dealers.size, days: o.days.size,
          carried_over: o.lines.filter(l => l.carried_over).length,
          changes: changesByOfficer[norm(o.emp_code)] || [],
          lines: o.lines.sort((a, b) => a.visit_date.localeCompare(b.visit_date) || a.sequence - b.sequence)
        }))
        .sort((a, b) => (b.carried_over - a.carried_over) || String(a.emp_code).localeCompare(String(b.emp_code)))
    });
  } catch (err) {
    console.error('[getC2Regeneration]', err);
    res.status(500).json({ error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN — re-run routing for a period without regenerating plans
// POST /api/app/routing/restamp   Body: { periodMonth, cycleCode? }
// ─────────────────────────────────────────────────────────────────────────────
export async function restampRouting(req, res) {
  try {
    const { periodMonth, cycleCode } = req.body || {};
    if (!periodMonth) return res.status(400).json({ error: 'periodMonth (YYYY-MM) is required.' });

    const { stampPlanRoutingForPeriod } = await import('../services/planRouting.service.js');
    const result = await stampPlanRoutingForPeriod(periodMonth, cycleCode || null);

    res.json({
      success: true,
      message: `Routing re-stamped for ${result.stamped} plan(s).`,
      ...result
    });
  } catch (err) {
    console.error('[restampRouting]', err);
    res.status(500).json({ error: err.message });
  }
}
