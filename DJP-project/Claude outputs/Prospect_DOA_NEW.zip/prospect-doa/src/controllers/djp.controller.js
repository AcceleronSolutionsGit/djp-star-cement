import { generateFullPjpDjpSolution } from '../engines/djp-generator.engine.js';
import { calculatePJP } from '../engines/pjp/pjp.engine.js';
import { generateDealerTrace } from '../engines/pjp/pjp-validator.engine.js';
import { reconcileUniverse } from '../engines/pjp/reconciliation.service.js';
import { checkAllExcelInputsAvailable } from '../engines/pjp/data-loader.engine.js';
import { AutoPlanGenerator } from '../engines/autoPlanGenerator.js';
import { dbAll, dbGet } from '../config/database.js';
import XLSX from 'xlsx';
import ExcelJS from 'exceljs';
import {
  COLUMNS as MASTER_COLUMNS, SHEET_NAME as MASTER_SHEET_NAME,
  HEADER_ROW, FIRST_DATA_ROW, buildHeaders, buildSources,
  buildRow, rowToArray, anchorDate, dedupeTargets
} from '../services/masterSheet.service.js';

/**
 * Run canonical PJP calculation only (without DJP allocation).
 */
export async function calculatePjp(req, res) {
  try {
    const planMonth = req.body.planMonth || req.body.periodMonth;
    const cycleCode = req.body.cycleCode || 'C1';

    if (!planMonth || typeof planMonth !== 'string') {
      return res.status(400).json({ error: 'planMonth is required. Please specify the planning month in YYYY-MM format.' });
    }
    const match = planMonth.match(/^(\d{4})-(\d{2})$/);
    if (!match) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Expected format is YYYY-MM.` });
    }
    const mNum = parseInt(match[2], 10);
    if (mNum < 1 || mNum > 12) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Month must be between 01 and 12.` });
    }
    const periodMonth = planMonth;

    // Verify all 5 Excel files are available before calculating
    const inputCheck = await checkAllExcelInputsAvailable();
    if (!inputCheck.allAvailable) {
      return res.status(400).json({
        error: `Cannot generate DJP: All 5 Excel input files must be uploaded and validated first. Currently missing: ${inputCheck.missing.join(', ')}.`
      });
    }

    const result = await calculatePJP(periodMonth, cycleCode, { persist: true });

    res.json({
      message: 'PJP Calculation Complete',
      periodMonth,
      cycleCode,
      stats: result.stats,
      validation: {
        valid: result.validation.valid,
        totalErrors: result.validation.totalErrors,
        totalDuplicates: result.validation.totalDuplicates,
        // Only return first 50 errors to avoid huge payloads
        errors: result.validation.errors.slice(0, 50)
      }
    });
  } catch (err) {
    console.error('Error calculating PJP:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Generate PJP + DJP for all roles.
 */
export async function generateAllRolePlans(req, res) {
  try {
    const planMonth = req.body.planMonth || req.body.periodMonth;
    const cycleCode = req.body.cycleCode || 'C1';

    if (!planMonth || typeof planMonth !== 'string') {
      return res.status(400).json({ error: 'planMonth is required. Please specify the planning month in YYYY-MM format.' });
    }
    const match = planMonth.match(/^(\d{4})-(\d{2})$/);
    if (!match) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Expected format is YYYY-MM.` });
    }
    const mNum = parseInt(match[2], 10);
    if (mNum < 1 || mNum > 12) {
      return res.status(400).json({ error: `Invalid planMonth: '${planMonth}'. Month must be between 01 and 12.` });
    }
    const periodMonth = planMonth;

    // Verify all 5 Excel files are available before calculating
    const inputCheck = await checkAllExcelInputsAvailable();
    if (!inputCheck.allAvailable) {
      return res.status(400).json({
        error: `Cannot generate DJP: All 5 Excel input files must be uploaded and validated first. Currently missing: ${inputCheck.missing.join(', ')}.`
      });
    }

    const result = await generateFullPjpDjpSolution(periodMonth, cycleCode);

    // Auto-generate plans for all roles in the hierarchy
    console.log(`[generateAllRolePlans] Auto-generating sales_plans for all hierarchy levels...`);
    const autoGen = new AutoPlanGenerator();

    const sos = await dbAll('SELECT DISTINCT so_emp_code as emp_code FROM dealer_visit_targets WHERE period_month = ? AND cycle_code = ? AND so_emp_code IS NOT NULL AND TRIM(so_emp_code) != ""', [periodMonth, cycleCode]);
    for (const s of sos) await autoGen.generatePlan(s.emp_code, periodMonth, 'SO', cycleCode).catch(e => console.warn(`SO plan gen error [${s.emp_code}]:`, e.message));

    const asms = await dbAll('SELECT DISTINCT asm_code as emp_code FROM dealer_visit_targets WHERE period_month = ? AND cycle_code = ? AND asm_code IS NOT NULL AND TRIM(asm_code) != ""', [periodMonth, cycleCode]);
    for (const a of asms) await autoGen.generatePlan(a.emp_code, periodMonth, 'ASM', cycleCode).catch(e => console.warn(`ASM plan gen error [${a.emp_code}]:`, e.message));

    const rsms = await dbAll('SELECT DISTINCT rsm_code as emp_code FROM dealer_visit_targets WHERE period_month = ? AND cycle_code = ? AND rsm_code IS NOT NULL AND TRIM(rsm_code) != ""', [periodMonth, cycleCode]);
    for (const r of rsms) await autoGen.generatePlan(r.emp_code, periodMonth, 'RSM', cycleCode).catch(e => console.warn(`RSM plan gen error [${r.emp_code}]:`, e.message));

    const zhs = await dbAll('SELECT DISTINCT zh_code as emp_code FROM dealer_visit_targets WHERE period_month = ? AND cycle_code = ? AND zh_code IS NOT NULL AND TRIM(zh_code) != ""', [periodMonth, cycleCode]);
    for (const z of zhs) await autoGen.generatePlan(z.emp_code, periodMonth, 'ZH', cycleCode).catch(e => console.warn(`ZH plan gen error [${z.emp_code}]:`, e.message));

    console.log(`[generateAllRolePlans] Finished auto-generating plans.`);

    res.json({
      message: 'Multi-Role PJP & DJP Solution Generated Successfully, and all Employee Plans were auto-generated.',
      periodMonth,
      cycleCode,
      ...result
    });
  } catch (err) {
    console.error('Error generating multi-role DJP:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get PJP debug trace for a specific dealer.
 */
export async function getPjpDebug(req, res) {
  try {
    const { dealerCode } = req.params;
    const { periodMonth, cycleCode } = req.query;

    if (!dealerCode) {
      return res.status(400).json({ error: 'dealerCode is required' });
    }

    const pm = periodMonth || req.query.planMonth;
    if (!pm || !/^\d{4}-\d{2}$/.test(pm)) {
      return res.status(400).json({ error: 'periodMonth query parameter is required (YYYY-MM)' });
    }
    const cc = cycleCode || 'C1';

    const pjp = await calculatePJP(pm, cc, { persist: false, debug: true });
    const dealer = pjp.results.find(r =>
      r.dealerCode === dealerCode ||
      r.dealerCode === dealerCode.toUpperCase()
    );

    if (!dealer) {
      return res.status(404).json({ error: `Dealer ${dealerCode} not found in PJP results` });
    }

    const trace = generateDealerTrace(dealer);
    res.json({ dealer, trace });
  } catch (err) {
    console.error('Error getting PJP debug:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Get dealer visit targets with pagination.
 */
export async function getDealerVisitTargets(req, res) {
  try {
    const { soEmpCode, soName, category, dealerStatus, custType, search, periodMonth, cycleCode, zone, area, limit, offset } = req.query;

    let sql = 'SELECT dvt.*, md.dealer_type FROM dealer_visit_targets dvt LEFT JOIN master_dealers md ON dvt.dealer_id = md.id WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM dealer_visit_targets dvt LEFT JOIN master_dealers md ON dvt.dealer_id = md.id WHERE 1=1';
    const params = [];
    const countParams = [];

    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle = cycleCode && cycleCode !== 'ALL' ? cycleCode : null;

    // Check if targetPeriod has records, if not fallback to latest period
    if (targetPeriod) {
      const exists = await dbGet('SELECT COUNT(*) as cnt FROM dealer_visit_targets WHERE period_month = ?', [targetPeriod]);
      if (!exists || exists.cnt === 0) {
        const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets ORDER BY period_month DESC LIMIT 1');
        if (latest) {
          targetPeriod = latest.period_month;
          if (!targetCycle) targetCycle = latest.cycle_code;
        }
      }
    } else {
      const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets ORDER BY period_month DESC LIMIT 1');
      if (latest) {
        targetPeriod = latest.period_month;
        if (!targetCycle) targetCycle = latest.cycle_code;
      }
    }

    if (custType && custType !== 'ALL') {
      if (custType === 'NON-STAR' || custType === 'NON_STAR') {
        sql += " AND (md.dealer_type = 'NON_STAR' OR md.dealer_type = 'NON-STAR')";
        countSql += " AND (md.dealer_type = 'NON_STAR' OR md.dealer_type = 'NON-STAR')";
      } else {
        sql += " AND md.dealer_type = ?";
        countSql += " AND md.dealer_type = ?";
        params.push(custType);
        countParams.push(custType);
      }
    }
    if (targetPeriod) {
      sql += ' AND dvt.period_month = ?';
      countSql += ' AND dvt.period_month = ?';
      params.push(targetPeriod);
      countParams.push(targetPeriod);
    }
    if (targetCycle) {
      sql += ' AND dvt.cycle_code = ?';
      countSql += ' AND dvt.cycle_code = ?';
      params.push(targetCycle);
      countParams.push(targetCycle);
    }
    if (zone && zone !== 'ALL') {
      sql += ' AND dvt.zone = ?';
      countSql += ' AND dvt.zone = ?';
      params.push(zone);
      countParams.push(zone);
    }
    if (area && area !== 'ALL') {
      sql += ' AND dvt.area = ?';
      countSql += ' AND dvt.area = ?';
      params.push(area);
      countParams.push(area);
    }
    if (soEmpCode && soEmpCode !== 'ALL') {
      sql += ' AND dvt.so_emp_code = ?';
      countSql += ' AND dvt.so_emp_code = ?';
      params.push(soEmpCode);
      countParams.push(soEmpCode);
    }
    if (soName && soName !== 'ALL') {
      sql += ' AND dvt.so_name = ?';
      countSql += ' AND dvt.so_name = ?';
      params.push(soName);
      countParams.push(soName);
    }
    if (category && category !== 'ALL') {
      sql += ' AND dvt.category = ?';
      countSql += ' AND dvt.category = ?';
      params.push(category);
      countParams.push(category);
    }
    if (dealerStatus && dealerStatus !== 'ALL') {
      sql += ' AND dvt.dealer_status = ?';
      countSql += ' AND dvt.dealer_status = ?';
      params.push(dealerStatus);
      countParams.push(dealerStatus);
    }
    if (search) {
      sql += ' AND (dvt.dealer_name LIKE ? OR dvt.sap_code LIKE ? OR dvt.area LIKE ? OR dvt.so_name LIKE ? OR dvt.zone LIKE ?)';
      countSql += ' AND (dvt.dealer_name LIKE ? OR dvt.sap_code LIKE ? OR dvt.area LIKE ? OR dvt.so_name LIKE ? OR dvt.zone LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s, s);
      countParams.push(s, s, s, s, s);
    }

    sql += ' ORDER BY dvt.category ASC, dvt.dealer_name ASC';

    const pageLimit = parseInt(limit || '50', 10);
    const pageOffset = parseInt(offset || '0', 10);
    sql += ' LIMIT ? OFFSET ?';
    params.push(pageLimit, pageOffset);

    const [targets, countObj] = await Promise.all([
      dbAll(sql, params),
      dbGet(countSql, countParams)
    ]);

    const formattedTargets = targets.map(t => {
      const soVisits = parseFloat(t.so_visits) || 0;
      const asmVisits = parseFloat(t.asm_visits) || 0;
      const rsmVisits = parseFloat(t.rsm_visits) || 0;
      const zhVisits = parseFloat(t.zh_visits) || 0;
      const totalVisits = t.total_visits !== undefined && t.total_visits !== null
        ? parseFloat(t.total_visits)
        : (soVisits + asmVisits + rsmVisits + zhVisits);

      const soVisitsPct = t.so_visits_pct !== undefined && t.so_visits_pct !== null
        ? parseFloat(t.so_visits_pct)
        : (totalVisits > 0 ? Math.round((soVisits / totalVisits) * 10000) / 100 : 0);

      const asmVisitsPct = t.asm_visits_pct !== undefined && t.asm_visits_pct !== null
        ? parseFloat(t.asm_visits_pct)
        : (totalVisits > 0 ? Math.round((asmVisits / totalVisits) * 10000) / 100 : 0);

      const rsmVisitsPct = t.rsm_visits_pct !== undefined && t.rsm_visits_pct !== null
        ? parseFloat(t.rsm_visits_pct)
        : (totalVisits > 0 ? Math.round((rsmVisits / totalVisits) * 10000) / 100 : 0);

      const zhVisitsPct = t.zh_visits_pct !== undefined && t.zh_visits_pct !== null
        ? parseFloat(t.zh_visits_pct)
        : (totalVisits > 0 ? Math.round((zhVisits / totalVisits) * 10000) / 100 : 0);

      return {
        ...t,
        total_visits: totalVisits,
        so_visits_pct: soVisitsPct,
        asm_visits_pct: asmVisitsPct,
        rsm_visits_pct: rsmVisitsPct,
        zh_visits_pct: zhVisitsPct
      };
    });

    res.json({ total: countObj?.total || formattedTargets.length, targets: formattedTargets });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getDjpPlan(req, res) {
  try {
    const { roleType, soEmpCode, empCode, periodMonth, cycleCode } = req.query;

    let sql = 'SELECT * FROM djp_recommendations WHERE 1=1';
    const params = [];

    if (roleType) {
      sql += ' AND role_type = ?';
      params.push(roleType);
    }
    if (soEmpCode) {
      sql += ' AND emp_code = ?';
      params.push(soEmpCode);
    }
    if (empCode) {
      sql += ' AND emp_code = ?';
      params.push(empCode);
    }
    if (periodMonth) {
      sql += ' AND period_month = ?';
      params.push(periodMonth);
    }
    if (cycleCode) {
      sql += ' AND cycle_code = ?';
      params.push(cycleCode);
    }

    sql += ' ORDER BY visit_date ASC, visit_sequence ASC';

    const plan = await dbAll(sql, params);
    res.json({ total: plan.length, plan });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

/**
 * Export the generated PJP_TRADE output as an Excel file with EXACTLY 16 columns.
 */
export async function exportPjpTradeExcel(req, res) {
  try {
    const { periodMonth, cycleCode } = req.query;

    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle = cycleCode && cycleCode !== 'ALL' ? cycleCode : null;

    if (!targetPeriod) {
      const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets WHERE period_month IS NOT NULL ORDER BY period_month DESC LIMIT 1');
      if (latest) {
        targetPeriod = latest.period_month;
        if (!targetCycle) targetCycle = latest.cycle_code || 'C1';
      }
    }

    let sql = `
      SELECT 
        dvt.*,
        dvt.sbg_block,
        dvt.dm_area,
        dvt.cust_type,
        dvt.priority_label,
        md.dealer_type,
        md.block as md_block
      FROM dealer_visit_targets dvt
      LEFT JOIN master_dealers md ON dvt.dealer_id = md.id
      WHERE 1=1
    `;
    const params = [];

    if (targetPeriod) {
      sql += ' AND dvt.period_month = ?';
      params.push(targetPeriod);
    }
    if (targetCycle) {
      sql += ' AND dvt.cycle_code = ?';
      params.push(targetCycle);
    }
    sql += ' ORDER BY dvt.zone ASC, dvt.category ASC, dvt.dealer_name ASC';

    let targets = await dbAll(sql, params);

    // Fallback: If nothing matched specific period/cycle, fetch all available targets
    if (!targets || targets.length === 0) {
      targets = await dbAll(`
        SELECT dvt.*, md.dealer_type, md.block
        FROM dealer_visit_targets dvt
        LEFT JOIN master_dealers md ON dvt.dealer_id = md.id
        ORDER BY dvt.zone ASC, dvt.category ASC, dvt.dealer_name ASC
      `);
    }

    if (!targets || targets.length === 0) {
      return res.status(404).json({ error: 'No PJP_TRADE data found. Please run DJP generation first.' });
    }

    // 2. Map strictly to the 16 requested columns
    const exportData = targets.map(t => {
      // Resolve Cust Type: Title Case ('Dealer' or 'Prospective')
      let rawType = String(t.cust_type || t.dealer_type || 'DEALER').toUpperCase();
      let custType = 'Dealer';
      if (rawType === 'PROSPECTIVE' || rawType === 'PROSPECT') {
        custType = 'Prospective';
      } else if (rawType === 'NON_STAR' || rawType === 'NON-STAR') {
        custType = 'Non-Star';
      }

      // Customer CODE: SAP if available, else SFA, else '-'.
      let custCode = t.sap_code || t.sfa_code || '-';

      // Block: MUST come from sbg_block (SBG authoritative) or prospect block, fallback '-'
      const block = t.sbg_block || t.block || '-';

      // Area: MUST come from dm_area (Dealer Mapping authoritative), fallback '-'
      const area = t.dm_area || t.area || '-';

      // Priority: numeric SO-wise priority rank (matching reference output)
      const priority = t.priority !== null && t.priority !== undefined ? Number(t.priority) : 1;

      const soVisits = parseFloat(t.so_visits) || 0;
      const asmVisits = parseFloat(t.asm_visits) || 0;
      const rsmVisits = parseFloat(t.rsm_visits) || 0;
      const zhVisits = parseFloat(t.zh_visits) || 0;

      return {
        'Zone': t.zone || '-',
        'Cust Type': custType,
        'Area': area,
        'Block': block,
        'ZONAL HEAD': t.zh_name || '-',
        'RSM': t.rsm_name || '-',
        'ASM': t.asm_name || '-',
        'SO/SE NAME': t.so_name || '-',
        'DEALER NAME': t.dealer_name || '-',
        'Customer CODE': custCode,
        'Priority': priority,
        'Category': t.dealer_status || '-',
        'No. of visits by SO': soVisits,
        'No. of visits by ASM': asmVisits,
        'Number of Visit by RSM': rsmVisits,
        'Number of Visit by ZH': zhVisits
      };
    });

    // 3. Create Workbook and Worksheet
    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'PJP_TRADE');

    // 4. Generate buffer
    const buf = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    // 5. Send as download
    const filename = `PJP_TRADE_${targetPeriod || '2026-06'}_${targetCycle || 'C1'}.xlsx`;
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);

  } catch (err) {
    console.error('Error exporting PJP_TRADE:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Export Master Report matching M_SAMPLE_EXPECTED.xlsx exactly (22 columns, sheet 'Report')
 */
export async function exportMasterExcel(req, res) {
  try {
    const { periodMonth, cycleCode } = req.query;
    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle  = cycleCode && cycleCode !== 'ALL' ? cycleCode : 'C1';

    if (!targetPeriod) {
      const latest = await dbGet(
        `SELECT period_month, cycle_code FROM dealer_visit_targets
          WHERE period_month IS NOT NULL ORDER BY period_month DESC LIMIT 1`);
      if (latest) {
        targetPeriod = latest.period_month;
        if (latest.cycle_code) targetCycle = latest.cycle_code;
      } else {
        targetPeriod = '2026-06';
      }
    }

    let targets = await dbAll(
      `SELECT * FROM dealer_visit_targets
        WHERE period_month = ? AND cycle_code = ?
        ORDER BY sap_code ASC, id ASC`, [targetPeriod, targetCycle]);

    if (!targets || targets.length === 0) {
      targets = await dbAll(
        `SELECT * FROM dealer_visit_targets WHERE period_month = ? ORDER BY sap_code ASC, id ASC`,
        [targetPeriod]);
    }

    if (!targets || targets.length === 0) {
      return res.status(400).json({
        error: `No PJP Master data found for period ${targetPeriod}. Please upload all 5 Excel files and click 'Generate DJP Plans' first.`
      });
    }

    const buf = await buildMasterWorkbook(dedupeTargets(targets), targetPeriod);

    const filename = `M_${targetPeriod}_${targetCycle}.xlsx`;
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
  } catch (err) {
    console.error('Error exporting Master report:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Write the Master workbook so it opens looking like the client's own M.xlsx.
 *
 * Layout, transcribed from M.xlsx -> sheet `Master ` (trailing space is real):
 *   row 1   blank
 *   row 2   B2 = planning anchor, a real date  (M.xlsx: 46174 = 2026-06-01)
 *   row 3   source-of-truth annotations
 *   row 4   headers, frozen
 *   row 5+  data
 *
 * Written with ExcelJS rather than SheetJS because the community build of SheetJS
 * cannot write fonts, fills or borders — and without those this is a spreadsheet that
 * merely contains the right values rather than one that looks like the client's.
 *
 * Exported for the verification test, which reads the bytes back and compares them
 * against the real M.xlsx.
 */
export async function buildMasterWorkbook(uniqueTargets, targetPeriod) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Star Cement PJP/DJP';
  wb.created = new Date();

  const ws = wb.addWorksheet(MASTER_SHEET_NAME, {
    views: [{ state: 'frozen', ySplit: HEADER_ROW }]     // freeze through the header row
  });

  ws.columns = MASTER_COLUMNS.map(c => ({
    width: c.width,
    hidden: !!c.hidden,
    style: c.fmt ? { numFmt: c.fmt } : undefined
  }));

  // ── row 1: blank ──────────────────────────────────────────────────────────
  ws.getRow(1).height = 15;

  // ── row 2: the planning anchor in B2 ──────────────────────────────────────
  const anchor = anchorDate(targetPeriod);
  if (anchor) {
    const b2 = ws.getCell('B2');
    b2.value  = anchor;
    b2.numFmt = '[$-409]dd-mmm-yy';
    b2.font   = { bold: true, size: 11 };
    b2.alignment = { horizontal: 'center', vertical: 'middle' };
  }

  // ── row 3: source annotations ─────────────────────────────────────────────
  const sourceRow = ws.getRow(3);
  buildSources().forEach((src, i) => {
    if (!src) return;
    const cell = sourceRow.getCell(i + 1);
    cell.value = src;
    cell.font  = { italic: true, size: 9, color: { argb: 'FF7F7F7F' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  });
  sourceRow.height = 22;

  // ── row 4: headers ────────────────────────────────────────────────────────
  const headerRow = ws.getRow(HEADER_ROW);
  buildHeaders(targetPeriod).forEach((h, i) => {
    const cell = headerRow.getCell(i + 1);
    cell.value = h;
    cell.font  = { bold: true, size: 10, color: { argb: 'FFFFFFFF' } };
    cell.fill  = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3864' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = {
      top:    { style: 'thin', color: { argb: 'FF17375E' } },
      left:   { style: 'thin', color: { argb: 'FF17375E' } },
      bottom: { style: 'thin', color: { argb: 'FF17375E' } },
      right:  { style: 'thin', color: { argb: 'FF17375E' } }
    };
  });
  headerRow.height = 58;   // the header text wraps to three lines in places

  // ── row 5+: data ──────────────────────────────────────────────────────────
  const EDGE = { style: 'thin', color: { argb: 'FFD9D9D9' } };
  uniqueTargets.forEach((t, idx) => {
    const values = rowToArray(buildRow(t, idx));
    const row = ws.getRow(FIRST_DATA_ROW + idx);
    values.forEach((v, i) => {
      const def  = MASTER_COLUMNS[i];
      const cell = row.getCell(i + 1);
      cell.value = v;                                  // real numbers and real Dates
      if (def.fmt) cell.numFmt = def.fmt;
      cell.alignment = { horizontal: def.align || 'left', vertical: 'middle' };
      cell.border = { top: EDGE, left: EDGE, bottom: EDGE, right: EDGE };
      cell.font = { size: 10 };
    });
  });

  // Autofilter over the header row, so the sheet is usable the moment it opens.
  ws.autoFilter = {
    from: { row: HEADER_ROW, column: 1 },
    to:   { row: HEADER_ROW + uniqueTargets.length, column: MASTER_COLUMNS.length }
  };

  return Buffer.from(await wb.xlsx.writeBuffer());
}

/**
 * Export Visits Report matching visits-To Be Achieved.xlsx reference format.
 * 
 * Reference format (verified from actual visits-To Be Achieved.xlsx):
 *   Sheet name: 'Visits'
 *   Row 1: blank
 *   Row 2: headers
 *   Row 3+: data
 * 
 * Columns (20 total):
 *   concat | Zone | Cust Type | Area | Block | ZONAL HEAD | RSM | ASM | SO/SE  NAME |
 *   DEALER NAME | Customer CODE (= SFA CODE) | Priority (numeric SO-wise rank) | Category |
 *   No. of visits by SO | No. of visits by ASM | Number of Visit by RSM | Number of Visit by ZH |
 *   Date of Visit 1 | Date of Visit 2 | Date of Visit 3
 * 
 * Rules:
 *   - Churn dealers EXCLUDED (no visits assigned)
 *   - Customer CODE = SFA CODE (not SAP code)
 *   - Priority = numeric priorityRank (SO-wise rank, e.g. 1, 2, 3...)
 */
export async function exportVisitsExcel(req, res) {
  try {
    const { periodMonth, cycleCode } = req.query;
    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle = cycleCode && cycleCode !== 'ALL' ? cycleCode : 'C1';

    if (!targetPeriod) {
      const latest = await dbGet('SELECT period_month, cycle_code FROM dealer_visit_targets WHERE period_month IS NOT NULL ORDER BY period_month DESC LIMIT 1');
      if (latest) {
        targetPeriod = latest.period_month;
        if (latest.cycle_code) targetCycle = latest.cycle_code;
      } else {
        targetPeriod = '2026-06';
      }
    }

    let targets = await dbAll(
      'SELECT * FROM dealer_visit_targets WHERE period_month = ? AND cycle_code = ? ORDER BY zone ASC, area ASC, so_name ASC, dealer_name ASC',
      [targetPeriod, targetCycle]
    );

    if (!targets || targets.length === 0) {
      targets = await dbAll(
        'SELECT * FROM dealer_visit_targets WHERE period_month = ? ORDER BY zone ASC, area ASC, so_name ASC, dealer_name ASC',
        [targetPeriod]
      );
    }

    if (!targets || targets.length === 0) {
      return res.status(400).json({ error: `No PJP Visits data found for period ${targetPeriod}. Please upload all 5 Excel files and click 'Generate DJP Plans' first.` });
    }

    const uniqueTargetsMap = new Map();
    for (const t of targets) {
      const code = t.sfa_code || t.sap_code;
      if (code) uniqueTargetsMap.set(code, t);
    }
    const uniqueTargets = [...uniqueTargetsMap.values()];

    const VISIT_HEADERS = [
      'concat', 'Zone', 'Cust Type', 'Area', 'Block', 'ZONAL HEAD', 'RSM', 'ASM', 'SO/SE  NAME',
      'DEALER NAME', 'Customer CODE', 'Priority', 'Category',
      'No. of visits by SO', 'No. of visits by ASM', 'Number of Visit by RSM', 'Number of Visit by ZH',
      'Date of Visit 1', 'Date of Visit 2', 'Date of Visit 3'
    ];

    const reportRows = [];

    for (const t of uniqueTargets) {
      const dealerStatus = t.dealer_status || '';
      if (dealerStatus === 'Churn') continue;

      const soVisits = parseFloat(t.so_visits) || 0;
      const asmVisits = parseFloat(t.asm_visits) || 0;
      const rsmVisits = parseFloat(t.rsm_visits) || 0;
      const zhVisits = parseFloat(t.zh_visits) || 0;

      if (soVisits === 0 && asmVisits === 0 && rsmVisits === 0 && zhVisits === 0) continue;

      const customerCode = t.sfa_code || t.sap_code || '';

      let custType = t.cust_type || 'DEALER';
      if (custType.toUpperCase() === 'NON_STAR' || custType.toUpperCase() === 'NON-STAR') {
        custType = 'NON STAR';
      } else if (custType.toUpperCase() === 'PROSPECTIVE') {
        custType = 'Prospective';
      } else if (custType.toUpperCase() === 'STAR') {
        custType = 'DEALER';
      }

      const priority = t.priority || 0;

      reportRows.push([
        null,
        t.zone || '',
        custType,
        t.dm_area || t.area || '',
        t.sbg_block || t.block || '',
        t.zh_name || '',
        t.rsm_name || '',
        t.asm_name || '',
        t.so_name || '',
        t.dealer_name || '',
        customerCode,
        priority,
        dealerStatus,
        soVisits,
        asmVisits,
        rsmVisits,
        zhVisits,
        null,
        null,
        null
      ]);
    }

    const worksheetData = [
      new Array(20).fill(null),
      VISIT_HEADERS,
      ...reportRows
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Visits');

    const exportBuf = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    const visitsFilename = `visits-To_Be_Achieved_${targetPeriod}_${targetCycle}.xlsx`;
    res.setHeader('Content-Disposition', `attachment; filename="${visitsFilename}"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(exportBuf);
  } catch (err) {
    console.error('Error exporting Visits report:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Return internal multi-source reconciliation report and diagnostics
 */
export async function getReconciliationDiagnostics(req, res) {
  try {
    const reportMonth = req.query.periodMonth || '2026-06';
    const cycleCode = req.query.cycleCode || 'C1';
    const result = await reconcileUniverse({ reportMonth, cycleCode });
    res.json(result);
  } catch (err) {
    console.error('Error getting reconciliation:', err);
    res.status(500).json({ error: err.message });
  }
}

/**
 * Check readiness of all 5 required Excel input documents.
 */
export async function getInputReadiness(req, res) {
  try {
    const status = await checkAllExcelInputsAvailable();
    res.json(status);
  } catch (err) {
    console.error('Error getting input readiness:', err);
    res.status(500).json({ error: err.message });
  }
}


/**
 * The Master sheet as JSON, for the on-screen view.
 * GET /api/djp/master-view?periodMonth=YYYY-MM&cycleCode=C1&page=1&pageSize=100
 *
 * Same 42 columns, same order, same values as the Excel download — both are built from
 * masterSheet.service.js, so the screen and the file cannot disagree.
 *
 * Paged, because the real master runs to ~12,600 rows and shipping that in one response
 * would stall the browser. `search` filters on dealer name, either code, area or SO.
 */
export async function getMasterView(req, res) {
  try {
    const { periodMonth, cycleCode, search } = req.query;
    const page     = Math.max(1, parseInt(req.query.page, 10) || 1);
    const pageSize = Math.min(500, Math.max(10, parseInt(req.query.pageSize, 10) || 100));

    let targetPeriod = periodMonth && periodMonth !== 'ALL' ? periodMonth : null;
    let targetCycle  = cycleCode && cycleCode !== 'ALL' ? cycleCode : 'C1';

    if (!targetPeriod) {
      const latest = await dbGet(
        `SELECT period_month, cycle_code FROM dealer_visit_targets
          WHERE period_month IS NOT NULL ORDER BY period_month DESC LIMIT 1`);
      if (!latest) {
        return res.status(400).json({
          error: 'No PJP Master data yet.',
          fix: "Upload the input files and click Generate Plans first."
        });
      }
      targetPeriod = latest.period_month;
      if (latest.cycle_code) targetCycle = latest.cycle_code;
    }

    let targets = await dbAll(
      `SELECT * FROM dealer_visit_targets
        WHERE period_month = ? AND cycle_code = ?
        ORDER BY sap_code ASC, id ASC`, [targetPeriod, targetCycle]);

    if (!targets || targets.length === 0) {
      targets = await dbAll(
        `SELECT * FROM dealer_visit_targets WHERE period_month = ? ORDER BY sap_code ASC, id ASC`,
        [targetPeriod]);
    }

    if (!targets || targets.length === 0) {
      return res.status(400).json({
        error: `No Master data for ${targetPeriod}.`,
        fix: "Upload the input files and click Generate Plans for this month."
      });
    }

    // Build every row first — Sl.No. must number the whole sheet, not the page.
    const all = dedupeTargets(targets).map((t, i) => buildRow(t, i));

    const q = String(search || '').trim().toLowerCase();
    const filtered = q
      ? all.filter(r =>
          String(r.dealer_name).toLowerCase().includes(q) ||
          String(r.customer_code).toLowerCase().includes(q) ||
          String(r.sfa_code).toLowerCase().includes(q) ||
          String(r.area).toLowerCase().includes(q) ||
          String(r.so_name).toLowerCase().includes(q))
      : all;

    const start = (page - 1) * pageSize;
    const rows  = filtered.slice(start, start + pageSize).map(r => {
      // Dates cross JSON as YYYY-MM-DD; the view formats them for display.
      const out = { ...r };
      // A real DOA crosses as YYYY-MM-DD; a prospect's marker ("NEW") is text and must
      // survive as text — nulling it would blank the cell the master fills in.
      out.doa = r.doa instanceof Date ? r.doa.toISOString().slice(0, 10)
              : (r.doa ? String(r.doa) : null);
      return out;
    });

    res.json({
      period_month: targetPeriod,
      cycle_code: targetCycle,
      sheet_name: MASTER_SHEET_NAME,
      header_row: HEADER_ROW,
      first_data_row: FIRST_DATA_ROW,
      anchor: anchorDate(targetPeriod)?.toISOString().slice(0, 10) || null,
      columns: MASTER_COLUMNS.map((c, i) => ({
        col: c.col, key: c.key, header: buildHeaders(targetPeriod)[i],
        source: c.source, align: c.align || 'left', fmt: c.fmt,
        hidden: !!c.hidden, width: c.width
      })),
      total: filtered.length,
      total_unfiltered: all.length,
      page, page_size: pageSize,
      pages: Math.max(1, Math.ceil(filtered.length / pageSize)),
      rows
    });
  } catch (err) {
    console.error('Error building Master view:', err);
    res.status(500).json({ error: err.message });
  }
}
